<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-17 07:35:36 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\personal-work\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2020-09-17 07:35:37 --> Unable to connect to the database
ERROR - 2020-09-17 07:35:45 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\personal-work\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2020-09-17 07:35:45 --> Unable to connect to the database
ERROR - 2020-09-17 07:35:49 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\personal-work\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2020-09-17 07:35:49 --> Unable to connect to the database
ERROR - 2020-09-17 08:29:21 --> Severity: Notice --> Undefined variable: activity_name C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 52
ERROR - 2020-09-17 08:29:21 --> Severity: Notice --> Undefined variable: activity_name C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 52
ERROR - 2020-09-17 08:32:07 --> Severity: error --> Exception: Too few arguments to function ActivityDb::view_single_act(), 0 passed in C:\xampp\htdocs\personal-work\application\controllers\Activity.php on line 73 and exactly 1 expected C:\xampp\htdocs\personal-work\application\models\ActivityDb.php 74
ERROR - 2020-09-17 08:32:52 --> Severity: Notice --> Undefined variable: activity_name C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 60
ERROR - 2020-09-17 09:31:14 --> Query error: Column 'created_by' cannot be null - Invalid query: INSERT INTO `intern_fees` (`intern_id`, `total_fees`, `remaining_amount`, `create_timestamp`, `created_by`, `intern_cancel`) VALUES ('7', '', '', '20200917130114', NULL, 0)
ERROR - 2020-09-17 10:46:00 --> Query error: Unknown column 'activity_type' in 'field list' - Invalid query: INSERT INTO `activity_fees` (`act_id`, `total_fees`, `activity_type`, `created_by`, `create_timestamp`, `last_modify_timestamp`, `last_modify_by`, `activity_cancel`) VALUES ('1', '2000', 'Workshop', '1', '20200917141600', '20200917141600', '1', 0)
ERROR - 2020-09-17 10:47:54 --> Severity: error --> Exception: Too few arguments to function Activity::add_fees(), 0 passed in C:\xampp\htdocs\personal-work\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\personal-work\application\controllers\Activity.php 71
ERROR - 2020-09-17 10:49:31 --> Severity: error --> Exception: Too few arguments to function Activity::add_fees(), 0 passed in C:\xampp\htdocs\personal-work\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\personal-work\application\controllers\Activity.php 71
ERROR - 2020-09-17 10:51:53 --> Severity: error --> Exception: Too few arguments to function Activity::add_fees(), 0 passed in C:\xampp\htdocs\personal-work\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\personal-work\application\controllers\Activity.php 71
ERROR - 2020-09-17 10:52:44 --> Severity: error --> Exception: Too few arguments to function ActivityDb::view_single_act(), 0 passed in C:\xampp\htdocs\personal-work\application\controllers\Activity.php on line 73 and exactly 1 expected C:\xampp\htdocs\personal-work\application\models\ActivityDb.php 74
ERROR - 2020-09-17 10:52:52 --> Severity: error --> Exception: Too few arguments to function Activity::add_fees(), 0 passed in C:\xampp\htdocs\personal-work\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\personal-work\application\controllers\Activity.php 71
ERROR - 2020-09-17 10:57:07 --> Severity: error --> Exception: Too few arguments to function Activity::add_fees(), 0 passed in C:\xampp\htdocs\personal-work\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\personal-work\application\controllers\Activity.php 71
ERROR - 2020-09-17 10:57:45 --> Severity: Notice --> Undefined variable: act_info C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 50
ERROR - 2020-09-17 10:57:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 50
ERROR - 2020-09-17 10:57:46 --> Severity: Notice --> Undefined variable: act_info C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 117
ERROR - 2020-09-17 10:57:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 117
ERROR - 2020-09-17 11:00:09 --> Severity: Notice --> Undefined variable: activity_type C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 60
ERROR - 2020-09-17 11:00:09 --> Severity: Notice --> Undefined variable: activity_type C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 60
ERROR - 2020-09-17 11:00:09 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 184
ERROR - 2020-09-17 11:00:09 --> Severity: Notice --> Trying to get property 'activity_type' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 184
ERROR - 2020-09-17 11:00:22 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 184
ERROR - 2020-09-17 11:00:22 --> Severity: Notice --> Trying to get property 'activity_type' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 184
ERROR - 2020-09-17 11:00:37 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 184
ERROR - 2020-09-17 11:00:37 --> Severity: Notice --> Trying to get property 'activity_type' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 184
ERROR - 2020-09-17 11:01:15 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 184
ERROR - 2020-09-17 11:01:15 --> Severity: Notice --> Trying to get property 'activity_type' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 184
ERROR - 2020-09-17 11:01:18 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 184
ERROR - 2020-09-17 11:01:18 --> Severity: Notice --> Trying to get property 'activity_type' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 184
ERROR - 2020-09-17 11:02:34 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 184
ERROR - 2020-09-17 11:02:34 --> Severity: Notice --> Trying to get property 'activity_type' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 184
ERROR - 2020-09-17 11:03:30 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 184
ERROR - 2020-09-17 11:03:30 --> Severity: Notice --> Trying to get property 'activity_type' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 184
ERROR - 2020-09-17 11:03:41 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 184
ERROR - 2020-09-17 11:03:41 --> Severity: Notice --> Trying to get property 'activity_type' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 184
ERROR - 2020-09-17 11:04:02 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 184
ERROR - 2020-09-17 11:04:02 --> Severity: Notice --> Trying to get property 'activity_type' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 184
ERROR - 2020-09-17 11:04:31 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 184
ERROR - 2020-09-17 11:04:31 --> Severity: Notice --> Trying to get property 'activity_type' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 184
ERROR - 2020-09-17 11:04:39 --> Query error: Column 'act_id' cannot be null - Invalid query: INSERT INTO `activity_fees` (`act_id`, `total_fees`, `created_by`, `create_timestamp`, `last_modify_timestamp`, `last_modify_by`, `activity_cancel`) VALUES (NULL, '5000', '1', '20200917143439', '20200917143439', '1', 0)
ERROR - 2020-09-17 11:05:02 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 184
ERROR - 2020-09-17 11:05:02 --> Severity: Notice --> Trying to get property 'activity_type' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 184
ERROR - 2020-09-17 11:39:43 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 184
ERROR - 2020-09-17 11:39:43 --> Severity: Notice --> Trying to get property 'activity_type' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 184
ERROR - 2020-09-17 11:39:50 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 184
ERROR - 2020-09-17 11:39:50 --> Severity: Notice --> Trying to get property 'activity_type' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 184
ERROR - 2020-09-17 11:40:26 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 184
ERROR - 2020-09-17 11:40:26 --> Severity: Notice --> Trying to get property 'activity_type' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 184
ERROR - 2020-09-17 11:47:26 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 185
ERROR - 2020-09-17 11:47:26 --> Severity: Notice --> Trying to get property 'activity_type' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 185
ERROR - 2020-09-17 11:54:13 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 184
ERROR - 2020-09-17 11:54:13 --> Severity: Notice --> Trying to get property 'activity_type' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 184
ERROR - 2020-09-17 12:08:45 --> Severity: Notice --> Undefined property: stdClass::$activity_type C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 176
ERROR - 2020-09-17 12:10:01 --> Severity: Notice --> Undefined property: stdClass::$activity_type C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 176
ERROR - 2020-09-17 12:10:46 --> Severity: error --> Exception: Too few arguments to function Activity::add_fees(), 0 passed in C:\xampp\htdocs\personal-work\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\personal-work\application\controllers\Activity.php 71
ERROR - 2020-09-17 12:11:04 --> Severity: error --> Exception: Too few arguments to function Activity::add_fees(), 0 passed in C:\xampp\htdocs\personal-work\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\personal-work\application\controllers\Activity.php 71
ERROR - 2020-09-17 12:13:59 --> Query error: Column 'act_id' cannot be null - Invalid query: INSERT INTO `activity_fees` (`act_id`, `total_fees`, `created_by`, `create_timestamp`, `last_modify_timestamp`, `last_modify_by`, `activity_cancel`) VALUES (NULL, '1000', '1', '20200917154359', '20200917154359', '1', 0)
ERROR - 2020-09-17 12:21:46 --> Query error: Column 'act_id' cannot be null - Invalid query: INSERT INTO `activity_fees` (`act_id`, `total_fees`, `created_by`, `create_timestamp`, `last_modify_timestamp`, `last_modify_by`, `activity_cancel`) VALUES (NULL, '1000', '1', '20200917155146', '20200917155146', '1', 0)
ERROR - 2020-09-17 12:23:38 --> Severity: error --> Exception: Too few arguments to function Activity::add_fees(), 0 passed in C:\xampp\htdocs\personal-work\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\personal-work\application\controllers\Activity.php 71
ERROR - 2020-09-17 12:23:45 --> Severity: error --> Exception: Too few arguments to function Activity::add_fees(), 0 passed in C:\xampp\htdocs\personal-work\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\personal-work\application\controllers\Activity.php 71
ERROR - 2020-09-17 12:27:14 --> Severity: error --> Exception: Too few arguments to function Activity::add_fees(), 0 passed in C:\xampp\htdocs\personal-work\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\personal-work\application\controllers\Activity.php 71
ERROR - 2020-09-17 12:27:16 --> Severity: Notice --> Undefined variable: activit_id C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 61
ERROR - 2020-09-17 12:27:16 --> Severity: Notice --> Undefined property: stdClass::$activity_type C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 177
ERROR - 2020-09-17 12:27:34 --> Severity: Notice --> Undefined property: stdClass::$activity_type C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 176
ERROR - 2020-09-17 12:27:40 --> Severity: error --> Exception: Too few arguments to function Activity::add_fees(), 0 passed in C:\xampp\htdocs\personal-work\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\personal-work\application\controllers\Activity.php 71
ERROR - 2020-09-17 12:38:00 --> Severity: error --> Exception: Too few arguments to function Activity::add_fees(), 0 passed in C:\xampp\htdocs\personal-work\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\personal-work\application\controllers\Activity.php 71
ERROR - 2020-09-17 12:57:48 --> Severity: error --> Exception: Too few arguments to function Activity::add_fees(), 0 passed in C:\xampp\htdocs\personal-work\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\personal-work\application\controllers\Activity.php 71
ERROR - 2020-09-17 12:59:16 --> Severity: Notice --> Undefined property: stdClass::$activity_type C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 176
ERROR - 2020-09-17 12:59:20 --> Severity: Notice --> Undefined property: stdClass::$activity_type C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 176
ERROR - 2020-09-17 12:59:20 --> Severity: Notice --> Undefined property: stdClass::$activity_type C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 176
ERROR - 2020-09-17 13:05:05 --> Severity: Notice --> Undefined property: stdClass::$activity_type C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 176
ERROR - 2020-09-17 13:05:33 --> Severity: Notice --> Undefined property: stdClass::$activity_type C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 176
ERROR - 2020-09-17 13:05:35 --> Severity: Notice --> Undefined property: stdClass::$activity_type C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 176
ERROR - 2020-09-17 13:05:51 --> Severity: Notice --> Undefined property: stdClass::$activity_type C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 176
ERROR - 2020-09-17 13:13:54 --> Severity: Notice --> Undefined property: stdClass::$activity_type C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 177
ERROR - 2020-09-17 13:14:05 --> Severity: Notice --> Undefined property: stdClass::$activity_type C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 177
ERROR - 2020-09-17 13:16:06 --> Severity: Notice --> Undefined property: stdClass::$activity_type C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 177
ERROR - 2020-09-17 13:27:37 --> Severity: Notice --> Undefined property: stdClass::$actvity_name C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 240
ERROR - 2020-09-17 13:28:18 --> Severity: Notice --> Undefined property: stdClass::$activity_type C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 240
ERROR - 2020-09-17 13:42:29 --> Severity: error --> Exception: Too few arguments to function Activity::add_fees(), 0 passed in C:\xampp\htdocs\personal-work\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\personal-work\application\controllers\Activity.php 71
ERROR - 2020-09-17 13:48:30 --> Severity: error --> Exception: Too few arguments to function Activity::add_fees(), 0 passed in C:\xampp\htdocs\personal-work\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\personal-work\application\controllers\Activity.php 71
