<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-23 07:08:20 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\personal-work\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2020-09-23 07:08:21 --> Unable to connect to the database
ERROR - 2020-09-23 07:38:43 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 288
ERROR - 2020-09-23 07:38:43 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 288
ERROR - 2020-09-23 07:38:43 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 288
ERROR - 2020-09-23 07:38:43 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 288
ERROR - 2020-09-23 07:44:43 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 07:44:43 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 07:44:43 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 07:44:43 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 07:44:44 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 07:44:44 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 07:44:44 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 07:44:44 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 07:44:49 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 07:44:49 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 07:44:49 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 07:44:49 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 07:44:53 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 07:44:53 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 07:44:53 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 07:44:53 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 07:46:07 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 286
ERROR - 2020-09-23 07:46:07 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 286
ERROR - 2020-09-23 07:46:07 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 286
ERROR - 2020-09-23 07:46:07 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 286
ERROR - 2020-09-23 07:46:46 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 286
ERROR - 2020-09-23 07:46:46 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 286
ERROR - 2020-09-23 07:46:46 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 286
ERROR - 2020-09-23 07:46:46 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 286
ERROR - 2020-09-23 07:46:50 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 286
ERROR - 2020-09-23 07:46:50 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 286
ERROR - 2020-09-23 07:46:50 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 286
ERROR - 2020-09-23 07:46:50 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 286
ERROR - 2020-09-23 07:49:59 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 286
ERROR - 2020-09-23 07:49:59 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 286
ERROR - 2020-09-23 07:49:59 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 286
ERROR - 2020-09-23 07:49:59 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 286
ERROR - 2020-09-23 07:57:57 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 07:57:57 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 07:57:57 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 07:57:57 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:01:01 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:01:01 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:01:01 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:01:01 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:01:06 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:01:06 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:01:06 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:01:06 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:02:04 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:02:04 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:02:04 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:02:04 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:02:33 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:02:33 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:02:33 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:02:33 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:02:37 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:02:37 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:02:37 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:02:37 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:04:34 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:04:34 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:04:34 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:04:34 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:04:39 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:04:39 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:04:39 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:04:39 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:08:12 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:08:12 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:08:12 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:08:12 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:08:19 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:08:19 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:08:19 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:08:19 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:08:22 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:08:22 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:08:22 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:08:23 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:08:55 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:08:55 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:08:55 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:08:55 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:09:00 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:09:00 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:09:00 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:09:00 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:09:05 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:09:05 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:09:05 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:09:05 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:09:09 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:09:09 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:09:09 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:09:09 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:09:10 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:09:10 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:09:10 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:09:10 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:09:12 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:09:12 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:09:12 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:09:12 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:27:37 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:27:37 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:27:37 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:27:37 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:36:45 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:36:45 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:36:45 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:36:45 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:36:51 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:36:51 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:36:51 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:36:51 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 289
ERROR - 2020-09-23 08:39:31 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 290
ERROR - 2020-09-23 08:39:31 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 290
ERROR - 2020-09-23 08:39:31 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 290
ERROR - 2020-09-23 08:39:31 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 290
ERROR - 2020-09-23 08:39:34 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 290
ERROR - 2020-09-23 08:39:34 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 290
ERROR - 2020-09-23 08:39:34 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 290
ERROR - 2020-09-23 08:39:34 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 290
ERROR - 2020-09-23 08:40:01 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 290
ERROR - 2020-09-23 08:40:01 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 290
ERROR - 2020-09-23 08:40:01 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 290
ERROR - 2020-09-23 08:40:01 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 290
ERROR - 2020-09-23 08:40:05 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 290
ERROR - 2020-09-23 08:40:05 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 290
ERROR - 2020-09-23 08:40:05 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 290
ERROR - 2020-09-23 08:40:05 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 290
ERROR - 2020-09-23 08:43:01 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 295
ERROR - 2020-09-23 08:43:01 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 295
ERROR - 2020-09-23 08:43:01 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 295
ERROR - 2020-09-23 08:43:01 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 295
ERROR - 2020-09-23 08:43:04 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 295
ERROR - 2020-09-23 08:43:04 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 295
ERROR - 2020-09-23 08:43:04 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 295
ERROR - 2020-09-23 08:43:04 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 295
ERROR - 2020-09-23 08:44:55 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 291
ERROR - 2020-09-23 08:44:55 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 291
ERROR - 2020-09-23 08:44:55 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 291
ERROR - 2020-09-23 08:44:55 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 291
ERROR - 2020-09-23 08:45:01 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 291
ERROR - 2020-09-23 08:45:01 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 291
ERROR - 2020-09-23 08:45:01 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 291
ERROR - 2020-09-23 08:45:01 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 291
ERROR - 2020-09-23 08:48:19 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 284
ERROR - 2020-09-23 08:48:19 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 284
ERROR - 2020-09-23 08:48:19 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 284
ERROR - 2020-09-23 08:48:19 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 284
ERROR - 2020-09-23 08:48:22 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 284
ERROR - 2020-09-23 08:48:22 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 284
ERROR - 2020-09-23 08:48:22 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 284
ERROR - 2020-09-23 08:48:22 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 284
ERROR - 2020-09-23 08:49:21 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 287
ERROR - 2020-09-23 08:49:21 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 287
ERROR - 2020-09-23 08:49:21 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 287
ERROR - 2020-09-23 08:49:21 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 287
ERROR - 2020-09-23 08:49:24 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 287
ERROR - 2020-09-23 08:49:24 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 287
ERROR - 2020-09-23 08:49:24 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 287
ERROR - 2020-09-23 08:49:24 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 287
ERROR - 2020-09-23 08:55:53 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 290
ERROR - 2020-09-23 08:55:53 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 290
ERROR - 2020-09-23 08:55:53 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 290
ERROR - 2020-09-23 08:55:53 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 290
ERROR - 2020-09-23 08:56:08 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 290
ERROR - 2020-09-23 08:56:08 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 290
ERROR - 2020-09-23 08:56:08 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 290
ERROR - 2020-09-23 08:56:08 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 290
ERROR - 2020-09-23 08:56:11 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 290
ERROR - 2020-09-23 08:56:11 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 290
ERROR - 2020-09-23 08:56:11 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 290
ERROR - 2020-09-23 08:56:11 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 290
ERROR - 2020-09-23 08:58:11 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 290
ERROR - 2020-09-23 08:58:11 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 290
ERROR - 2020-09-23 08:58:11 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 290
ERROR - 2020-09-23 08:58:11 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 290
ERROR - 2020-09-23 08:58:15 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 290
ERROR - 2020-09-23 08:58:15 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 290
ERROR - 2020-09-23 08:58:15 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 290
ERROR - 2020-09-23 08:58:15 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 290
ERROR - 2020-09-23 09:12:55 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 290
ERROR - 2020-09-23 09:12:55 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 290
ERROR - 2020-09-23 09:12:55 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 290
ERROR - 2020-09-23 09:12:55 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 290
ERROR - 2020-09-23 09:45:27 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 297
ERROR - 2020-09-23 09:45:27 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 297
ERROR - 2020-09-23 09:45:33 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 297
ERROR - 2020-09-23 09:45:33 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 297
ERROR - 2020-09-23 09:59:03 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 298
ERROR - 2020-09-23 09:59:03 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 298
ERROR - 2020-09-23 10:10:54 --> Severity: Notice --> Undefined variable: check_fees C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 91
ERROR - 2020-09-23 10:10:54 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 298
ERROR - 2020-09-23 10:10:54 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 298
ERROR - 2020-09-23 10:11:31 --> Severity: Notice --> Undefined variable: check_fees C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 91
ERROR - 2020-09-23 10:11:31 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 298
ERROR - 2020-09-23 10:11:31 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 298
ERROR - 2020-09-23 10:11:52 --> Severity: Notice --> Undefined variable: check_fees C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 91
ERROR - 2020-09-23 10:11:52 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 298
ERROR - 2020-09-23 10:11:52 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 298
ERROR - 2020-09-23 10:12:05 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 298
ERROR - 2020-09-23 10:12:05 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 298
ERROR - 2020-09-23 10:14:01 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 297
ERROR - 2020-09-23 10:14:01 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 297
ERROR - 2020-09-23 10:19:24 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 297
ERROR - 2020-09-23 10:19:24 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 297
ERROR - 2020-09-23 17:06:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\personal-work\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2020-09-23 17:06:02 --> Unable to connect to the database
ERROR - 2020-09-23 17:11:25 --> Query error: Column 'created_by' cannot be null - Invalid query: INSERT INTO `activity_transaction` (`act_id`, `currentpay_amount`, `payment_mode`, `payment_date`, `create_timestamp`, `account_holder_name`, `bank_name`, `cheque_number`, `ifsc_code`, `branch_name`, `upi_transaction_id`, `transaction_name`, `transaction_mobile`, `google_transaction_id`, `bank_transaction_id`, `created_by`, `last_modify_timestamp`, `last_modify_by`, `transc_cancel_status`, `transc_cancel_reason`) VALUES ('14', '1000', 'Cash', '2020-09-23', '2020-09-23', '', '', '', '', '', '', '', '', '', '', NULL, '2020-09-23', NULL, 0, '')
ERROR - 2020-09-23 17:11:59 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 377
ERROR - 2020-09-23 17:12:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 378
ERROR - 2020-09-23 17:13:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 377
ERROR - 2020-09-23 17:13:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 378
ERROR - 2020-09-23 17:20:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 377
ERROR - 2020-09-23 17:20:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 378
ERROR - 2020-09-23 17:32:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 377
ERROR - 2020-09-23 17:32:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 378
ERROR - 2020-09-23 17:32:53 --> Severity: error --> Exception: Too few arguments to function ActivityDb::update_act_fees(), 2 passed in C:\xampp\htdocs\personal-work\application\controllers\Activity.php on line 381 and exactly 3 expected C:\xampp\htdocs\personal-work\application\models\ActivityDb.php 299
