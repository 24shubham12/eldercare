<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-25 08:00:02 --> Severity: Compile Error --> Cannot use [] for reading C:\xampp\htdocs\senior_care\application\controllers\Users.php 49
ERROR - 2021-02-25 10:40:08 --> Severity: error --> Exception: syntax error, unexpected 'print_r' (T_STRING), expecting ';' or ',' C:\xampp\htdocs\senior_care\application\controllers\Users.php 64
ERROR - 2021-02-25 11:00:04 --> Severity: error --> Exception: Call to undefined function printr() C:\xampp\htdocs\senior_care\application\controllers\Users.php 64
ERROR - 2021-02-25 11:44:36 --> 404 Page Not Found: Patient_login/index
ERROR - 2021-02-25 12:49:57 --> Query error: Table 'senior_care.users' doesn't exist - Invalid query: SELECT *
FROM `users`
WHERE `email` = '24shubham12@gmail.com'
ERROR - 2021-02-25 13:32:38 --> 404 Page Not Found: Users/vali_patient_login
ERROR - 2021-02-25 13:34:46 --> 404 Page Not Found: Users/elders_home
ERROR - 2021-02-25 14:38:33 --> 404 Page Not Found: Users/style.css
ERROR - 2021-02-25 14:38:40 --> 404 Page Not Found: Users/style.css
ERROR - 2021-02-25 14:38:43 --> 404 Page Not Found: Users/style.css
ERROR - 2021-02-25 14:56:05 --> Severity: Notice --> Undefined property: CI_Loader::$Admin_model C:\xampp\htdocs\senior_care\application\views\admin\assets\common_header.php 4
ERROR - 2021-02-25 14:56:06 --> Severity: error --> Exception: Call to a member function admin_login() on null C:\xampp\htdocs\senior_care\application\views\admin\assets\common_header.php 4
ERROR - 2021-02-25 14:58:15 --> Severity: Notice --> Undefined property: CI_Loader::$Admin_model C:\xampp\htdocs\senior_care\application\views\admin\assets\common_header.php 4
ERROR - 2021-02-25 14:58:15 --> Severity: error --> Exception: Call to a member function admin_login() on null C:\xampp\htdocs\senior_care\application\views\admin\assets\common_header.php 4
ERROR - 2021-02-25 15:02:25 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\senior_care\application\views\admin\assets\common_header.php 58
ERROR - 2021-02-25 15:02:25 --> Severity: Notice --> Trying to get property 'user_name' of non-object C:\xampp\htdocs\senior_care\application\views\admin\assets\common_header.php 58
ERROR - 2021-02-25 15:02:25 --> Severity: Notice --> Undefined variable: profile C:\xampp\htdocs\senior_care\application\views\admin\assets\common_sidebar.php 9
ERROR - 2021-02-25 15:02:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\senior_care\application\views\admin\assets\common_sidebar.php 9
ERROR - 2021-02-25 15:02:25 --> Severity: Notice --> Undefined variable: total_interns C:\xampp\htdocs\senior_care\application\views\users\dashboard.php 45
ERROR - 2021-02-25 15:02:25 --> Severity: Notice --> Undefined variable: total_active_subscriptions C:\xampp\htdocs\senior_care\application\views\users\dashboard.php 56
ERROR - 2021-02-25 15:02:25 --> Severity: Notice --> Undefined variable: total_halt_subscriptions C:\xampp\htdocs\senior_care\application\views\users\dashboard.php 68
ERROR - 2021-02-25 15:02:25 --> Severity: Notice --> Undefined variable: total_completed_subscriptions C:\xampp\htdocs\senior_care\application\views\users\dashboard.php 78
ERROR - 2021-02-25 15:03:05 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\senior_care\application\views\admin\assets\common_header.php 58
ERROR - 2021-02-25 15:03:05 --> Severity: Notice --> Trying to get property 'user_name' of non-object C:\xampp\htdocs\senior_care\application\views\admin\assets\common_header.php 58
ERROR - 2021-02-25 15:03:05 --> Severity: Notice --> Undefined variable: profile C:\xampp\htdocs\senior_care\application\views\admin\assets\common_sidebar.php 9
ERROR - 2021-02-25 15:03:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\senior_care\application\views\admin\assets\common_sidebar.php 9
ERROR - 2021-02-25 15:03:05 --> Severity: Notice --> Undefined variable: total_interns C:\xampp\htdocs\senior_care\application\views\users\dashboard.php 45
ERROR - 2021-02-25 15:03:05 --> Severity: Notice --> Undefined variable: total_active_subscriptions C:\xampp\htdocs\senior_care\application\views\users\dashboard.php 56
ERROR - 2021-02-25 15:03:05 --> Severity: Notice --> Undefined variable: total_halt_subscriptions C:\xampp\htdocs\senior_care\application\views\users\dashboard.php 68
ERROR - 2021-02-25 15:03:05 --> Severity: Notice --> Undefined variable: total_completed_subscriptions C:\xampp\htdocs\senior_care\application\views\users\dashboard.php 78
ERROR - 2021-02-25 15:03:48 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\senior_care\application\views\admin\assets\common_header.php 58
ERROR - 2021-02-25 15:03:48 --> Severity: Notice --> Trying to get property 'user_name' of non-object C:\xampp\htdocs\senior_care\application\views\admin\assets\common_header.php 58
ERROR - 2021-02-25 15:03:48 --> Severity: Notice --> Undefined variable: profile C:\xampp\htdocs\senior_care\application\views\admin\assets\common_sidebar.php 9
ERROR - 2021-02-25 15:03:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\senior_care\application\views\admin\assets\common_sidebar.php 9
ERROR - 2021-02-25 15:03:48 --> Severity: Notice --> Undefined variable: total_interns C:\xampp\htdocs\senior_care\application\views\users\dashboard.php 45
ERROR - 2021-02-25 15:03:48 --> Severity: Notice --> Undefined variable: total_active_subscriptions C:\xampp\htdocs\senior_care\application\views\users\dashboard.php 56
ERROR - 2021-02-25 15:03:48 --> Severity: Notice --> Undefined variable: total_halt_subscriptions C:\xampp\htdocs\senior_care\application\views\users\dashboard.php 68
ERROR - 2021-02-25 15:03:48 --> Severity: Notice --> Undefined variable: total_completed_subscriptions C:\xampp\htdocs\senior_care\application\views\users\dashboard.php 78
ERROR - 2021-02-25 15:04:03 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\senior_care\application\views\admin\assets\common_header.php 58
ERROR - 2021-02-25 15:04:03 --> Severity: Notice --> Trying to get property 'user_name' of non-object C:\xampp\htdocs\senior_care\application\views\admin\assets\common_header.php 58
ERROR - 2021-02-25 15:04:03 --> Severity: Notice --> Undefined variable: profile C:\xampp\htdocs\senior_care\application\views\admin\assets\common_sidebar.php 9
ERROR - 2021-02-25 15:04:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\senior_care\application\views\admin\assets\common_sidebar.php 9
ERROR - 2021-02-25 15:04:03 --> Severity: Notice --> Undefined variable: total_interns C:\xampp\htdocs\senior_care\application\views\users\dashboard.php 45
ERROR - 2021-02-25 15:04:03 --> Severity: Notice --> Undefined variable: total_active_subscriptions C:\xampp\htdocs\senior_care\application\views\users\dashboard.php 56
ERROR - 2021-02-25 15:04:03 --> Severity: Notice --> Undefined variable: total_halt_subscriptions C:\xampp\htdocs\senior_care\application\views\users\dashboard.php 68
ERROR - 2021-02-25 15:04:03 --> Severity: Notice --> Undefined variable: total_completed_subscriptions C:\xampp\htdocs\senior_care\application\views\users\dashboard.php 78
ERROR - 2021-02-25 15:04:52 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\senior_care\application\views\admin\assets\common_header.php 58
ERROR - 2021-02-25 15:04:52 --> Severity: Notice --> Trying to get property 'user_name' of non-object C:\xampp\htdocs\senior_care\application\views\admin\assets\common_header.php 58
ERROR - 2021-02-25 15:04:52 --> Severity: Notice --> Undefined variable: profile C:\xampp\htdocs\senior_care\application\views\admin\assets\common_sidebar.php 9
ERROR - 2021-02-25 15:04:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\senior_care\application\views\admin\assets\common_sidebar.php 9
ERROR - 2021-02-25 15:04:52 --> Severity: Notice --> Undefined variable: total_interns C:\xampp\htdocs\senior_care\application\views\users\dashboard.php 45
ERROR - 2021-02-25 15:04:52 --> Severity: Notice --> Undefined variable: total_active_subscriptions C:\xampp\htdocs\senior_care\application\views\users\dashboard.php 56
ERROR - 2021-02-25 15:04:52 --> Severity: Notice --> Undefined variable: total_halt_subscriptions C:\xampp\htdocs\senior_care\application\views\users\dashboard.php 68
ERROR - 2021-02-25 15:04:52 --> Severity: Notice --> Undefined variable: total_completed_subscriptions C:\xampp\htdocs\senior_care\application\views\users\dashboard.php 78
ERROR - 2021-02-25 15:05:23 --> Severity: Notice --> Undefined variable: profile C:\xampp\htdocs\senior_care\application\views\admin\assets\common_sidebar.php 9
ERROR - 2021-02-25 15:05:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\senior_care\application\views\admin\assets\common_sidebar.php 9
ERROR - 2021-02-25 15:05:23 --> Severity: Notice --> Undefined variable: total_interns C:\xampp\htdocs\senior_care\application\views\users\dashboard.php 45
ERROR - 2021-02-25 15:05:23 --> Severity: Notice --> Undefined variable: total_active_subscriptions C:\xampp\htdocs\senior_care\application\views\users\dashboard.php 56
ERROR - 2021-02-25 15:05:23 --> Severity: Notice --> Undefined variable: total_halt_subscriptions C:\xampp\htdocs\senior_care\application\views\users\dashboard.php 68
ERROR - 2021-02-25 15:05:23 --> Severity: Notice --> Undefined variable: total_completed_subscriptions C:\xampp\htdocs\senior_care\application\views\users\dashboard.php 78
ERROR - 2021-02-25 16:25:20 --> 404 Page Not Found: Users/application
ERROR - 2021-02-25 16:25:20 --> 404 Page Not Found: Users/application
ERROR - 2021-02-25 16:25:20 --> 404 Page Not Found: Users/application
ERROR - 2021-02-25 16:25:20 --> 404 Page Not Found: Users/application
ERROR - 2021-02-25 16:25:20 --> 404 Page Not Found: Users/application
ERROR - 2021-02-25 16:25:20 --> 404 Page Not Found: Users/application
ERROR - 2021-02-25 16:25:20 --> 404 Page Not Found: Users/application
ERROR - 2021-02-25 16:25:20 --> 404 Page Not Found: Users/application
ERROR - 2021-02-25 16:25:20 --> 404 Page Not Found: Users/application
ERROR - 2021-02-25 16:25:20 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-25 16:25:20 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-25 16:25:20 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-25 16:25:20 --> 404 Page Not Found: Users/application
ERROR - 2021-02-25 16:25:20 --> 404 Page Not Found: Users/application
ERROR - 2021-02-25 16:25:21 --> 404 Page Not Found: Users/application
ERROR - 2021-02-25 16:25:21 --> 404 Page Not Found: Users/application
ERROR - 2021-02-25 16:25:21 --> 404 Page Not Found: Users/application
ERROR - 2021-02-25 16:25:21 --> 404 Page Not Found: Users/application
ERROR - 2021-02-25 16:25:21 --> 404 Page Not Found: Users/application
ERROR - 2021-02-25 16:25:21 --> 404 Page Not Found: Users/application
ERROR - 2021-02-25 16:30:12 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-25 16:30:12 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-25 16:30:12 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-25 16:35:29 --> 404 Page Not Found: Users/index.html
ERROR - 2021-02-25 16:35:50 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-25 16:35:50 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-25 16:35:50 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-25 16:40:18 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-25 16:40:18 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-25 16:40:18 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-25 16:40:41 --> 404 Page Not Found: Users/index.html
ERROR - 2021-02-25 16:40:54 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-25 16:40:54 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-25 16:40:54 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-25 16:41:06 --> 404 Page Not Found: Users/pages-profile.html
ERROR - 2021-02-25 16:41:22 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-25 16:41:22 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-25 16:41:22 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-25 16:42:07 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-25 16:45:57 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-25 16:46:37 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-25 16:46:55 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-25 16:47:20 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-25 16:47:39 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-25 16:52:14 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-25 16:52:36 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-25 16:52:52 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-25 18:11:28 --> Severity: Notice --> Undefined variable: patient_record C:\xampp\htdocs\senior_care\application\views\users\dashboard.php 103
ERROR - 2021-02-25 18:11:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\senior_care\application\views\users\dashboard.php 103
ERROR - 2021-02-25 18:14:38 --> Severity: Notice --> Undefined variable: patient_record C:\xampp\htdocs\senior_care\application\views\users\dashboard.php 103
ERROR - 2021-02-25 18:14:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\senior_care\application\views\users\dashboard.php 103
ERROR - 2021-02-25 18:14:41 --> Severity: Notice --> Undefined variable: patient_record C:\xampp\htdocs\senior_care\application\views\users\dashboard.php 103
ERROR - 2021-02-25 18:14:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\senior_care\application\views\users\dashboard.php 103
ERROR - 2021-02-25 18:30:27 --> Severity: Notice --> Undefined variable: patient_record C:\xampp\htdocs\senior_care\application\views\users\dashboard.php 103
ERROR - 2021-02-25 18:30:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\senior_care\application\views\users\dashboard.php 103
ERROR - 2021-02-25 18:30:49 --> Severity: Notice --> Undefined variable: patient_record C:\xampp\htdocs\senior_care\application\views\users\dashboard.php 103
ERROR - 2021-02-25 18:30:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\senior_care\application\views\users\dashboard.php 103
ERROR - 2021-02-25 18:35:47 --> Severity: Notice --> Undefined variable: patient_record C:\xampp\htdocs\senior_care\application\views\users\dashboard.php 103
ERROR - 2021-02-25 18:35:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\senior_care\application\views\users\dashboard.php 103
ERROR - 2021-02-25 18:35:57 --> Severity: Notice --> Undefined variable: patient_record C:\xampp\htdocs\senior_care\application\views\users\dashboard.php 103
ERROR - 2021-02-25 18:35:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\senior_care\application\views\users\dashboard.php 103
ERROR - 2021-02-25 18:36:14 --> Severity: Notice --> Undefined variable: patient_record C:\xampp\htdocs\senior_care\application\views\users\dashboard.php 103
ERROR - 2021-02-25 18:36:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\senior_care\application\views\users\dashboard.php 103
ERROR - 2021-02-25 18:42:49 --> Severity: Notice --> Undefined variable: patient_record C:\xampp\htdocs\senior_care\application\views\users\dashboard.php 103
ERROR - 2021-02-25 18:42:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\senior_care\application\views\users\dashboard.php 103
ERROR - 2021-02-25 18:42:55 --> Severity: Notice --> Undefined variable: patient_record C:\xampp\htdocs\senior_care\application\views\users\dashboard.php 103
ERROR - 2021-02-25 18:42:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\senior_care\application\views\users\dashboard.php 103
ERROR - 2021-02-25 19:59:20 --> 404 Page Not Found: Users/icon-material.html
ERROR - 2021-02-25 20:45:22 --> Severity: Notice --> Undefined variable: patient_record C:\xampp\htdocs\senior_care\application\views\users\accounts.php 103
ERROR - 2021-02-25 20:45:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\senior_care\application\views\users\accounts.php 103
ERROR - 2021-02-25 20:49:06 --> Severity: error --> Exception: Call to undefined method PatientDb::fetch_patient_recs() C:\xampp\htdocs\senior_care\application\controllers\Users.php 42
ERROR - 2021-02-25 20:54:24 --> Severity: Notice --> Undefined variable: row_quiz C:\xampp\htdocs\senior_care\application\views\users\accounts.php 93
ERROR - 2021-02-25 20:54:24 --> Severity: Notice --> Trying to get property 'total_question' of non-object C:\xampp\htdocs\senior_care\application\views\users\accounts.php 93
ERROR - 2021-02-25 22:35:06 --> 404 Page Not Found: Admin/dashboard
ERROR - 2021-02-25 22:35:38 --> 404 Page Not Found: Admin/dashboard
ERROR - 2021-02-25 22:35:46 --> 404 Page Not Found: Admin/dashboard
ERROR - 2021-02-25 22:37:54 --> Severity: Notice --> Undefined variable: patient_record C:\xampp\htdocs\senior_care\application\views\admin\dashboard.php 99
ERROR - 2021-02-25 22:37:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\senior_care\application\views\admin\dashboard.php 99
