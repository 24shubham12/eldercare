<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-04 14:50:49 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\perso-work\application\views\admin\activity\add_fees.php 327
ERROR - 2020-10-04 14:50:49 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\perso-work\application\views\admin\activity\add_fees.php 327
ERROR - 2020-10-04 15:02:11 --> Severity: Notice --> Undefined variable: row_data C:\xampp\htdocs\perso-work\application\views\admin\activity\manage_activity.php 83
ERROR - 2020-10-04 15:05:25 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\perso-work\application\views\admin\activity\add_fees.php 327
ERROR - 2020-10-04 15:05:25 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\perso-work\application\views\admin\activity\add_fees.php 327
