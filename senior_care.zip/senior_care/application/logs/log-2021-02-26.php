<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-26 00:49:47 --> 404 Page Not Found: Users/confirm_appoint
ERROR - 2021-02-26 01:01:26 --> Severity: Notice --> Undefined property: Admin::$ApartmentDb C:\xampp\htdocs\senior_care\application\controllers\Admin.php 71
ERROR - 2021-02-26 01:01:26 --> Severity: error --> Exception: Call to a member function view_apt_member() on null C:\xampp\htdocs\senior_care\application\controllers\Admin.php 71
ERROR - 2021-02-26 01:04:28 --> Severity: error --> Exception: Call to undefined method PatientDb::view_apt_member() C:\xampp\htdocs\senior_care\application\controllers\Admin.php 74
ERROR - 2021-02-26 01:05:55 --> Severity: error --> Exception: Call to undefined method Admin::uri_segment() C:\xampp\htdocs\senior_care\application\controllers\Admin.php 71
ERROR - 2021-02-26 01:16:33 --> Severity: Notice --> Undefined variable: records C:\xampp\htdocs\senior_care\application\views\admin\view_patient.php 86
ERROR - 2021-02-26 01:16:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\senior_care\application\views\admin\view_patient.php 86
ERROR - 2021-02-26 01:16:53 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\senior_care\application\views\admin\view_patient.php 92
ERROR - 2021-02-26 01:16:53 --> Severity: Notice --> Trying to get property 'firstname' of non-object C:\xampp\htdocs\senior_care\application\views\admin\view_patient.php 92
ERROR - 2021-02-26 01:16:53 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\senior_care\application\views\admin\view_patient.php 97
ERROR - 2021-02-26 01:16:53 --> Severity: Notice --> Trying to get property 'lastname' of non-object C:\xampp\htdocs\senior_care\application\views\admin\view_patient.php 97
ERROR - 2021-02-26 01:16:53 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\senior_care\application\views\admin\view_patient.php 102
ERROR - 2021-02-26 01:16:53 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\senior_care\application\views\admin\view_patient.php 102
ERROR - 2021-02-26 01:16:53 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\senior_care\application\views\admin\view_patient.php 109
ERROR - 2021-02-26 01:16:53 --> Severity: Notice --> Trying to get property 'contact' of non-object C:\xampp\htdocs\senior_care\application\views\admin\view_patient.php 109
ERROR - 2021-02-26 01:16:53 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\senior_care\application\views\admin\view_patient.php 114
ERROR - 2021-02-26 01:16:53 --> Severity: Notice --> Trying to get property 'apndate' of non-object C:\xampp\htdocs\senior_care\application\views\admin\view_patient.php 114
ERROR - 2021-02-26 01:16:53 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\senior_care\application\views\admin\view_patient.php 119
ERROR - 2021-02-26 01:16:53 --> Severity: Notice --> Trying to get property 'dob' of non-object C:\xampp\htdocs\senior_care\application\views\admin\view_patient.php 119
ERROR - 2021-02-26 01:16:53 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\senior_care\application\views\admin\view_patient.php 126
ERROR - 2021-02-26 01:16:53 --> Severity: Notice --> Trying to get property 'age' of non-object C:\xampp\htdocs\senior_care\application\views\admin\view_patient.php 126
ERROR - 2021-02-26 01:16:53 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\senior_care\application\views\admin\view_patient.php 131
ERROR - 2021-02-26 01:16:53 --> Severity: Notice --> Trying to get property 'height' of non-object C:\xampp\htdocs\senior_care\application\views\admin\view_patient.php 131
ERROR - 2021-02-26 01:16:53 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\senior_care\application\views\admin\view_patient.php 136
ERROR - 2021-02-26 01:16:53 --> Severity: Notice --> Trying to get property 'weight' of non-object C:\xampp\htdocs\senior_care\application\views\admin\view_patient.php 136
ERROR - 2021-02-26 01:16:53 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\senior_care\application\views\admin\view_patient.php 143
ERROR - 2021-02-26 01:16:54 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\senior_care\application\views\admin\view_patient.php 143
ERROR - 2021-02-26 01:16:54 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\senior_care\application\views\admin\view_patient.php 148
ERROR - 2021-02-26 01:16:54 --> Severity: Notice --> Trying to get property 'medcondition' of non-object C:\xampp\htdocs\senior_care\application\views\admin\view_patient.php 148
ERROR - 2021-02-26 01:17:52 --> Severity: Notice --> Undefined variable: totrecords C:\xampp\htdocs\senior_care\application\views\admin\view_patient.php 86
ERROR - 2021-02-26 01:17:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\senior_care\application\views\admin\view_patient.php 86
ERROR - 2021-02-26 01:21:39 --> Severity: Notice --> Undefined variable: totrecords C:\xampp\htdocs\senior_care\application\views\admin\view_patient.php 86
ERROR - 2021-02-26 01:21:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\senior_care\application\views\admin\view_patient.php 86
ERROR - 2021-02-26 01:21:42 --> Severity: Notice --> Undefined variable: totrecords C:\xampp\htdocs\senior_care\application\views\admin\view_patient.php 86
ERROR - 2021-02-26 01:21:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\senior_care\application\views\admin\view_patient.php 86
ERROR - 2021-02-26 01:24:45 --> Severity: Notice --> Undefined variable: totrecords C:\xampp\htdocs\senior_care\application\views\admin\view_patient.php 86
ERROR - 2021-02-26 01:24:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\senior_care\application\views\admin\view_patient.php 86
ERROR - 2021-02-26 01:25:28 --> Severity: Notice --> Undefined variable: userdata C:\xampp\htdocs\senior_care\application\views\admin\view_patient.php 86
ERROR - 2021-02-26 01:25:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\senior_care\application\views\admin\view_patient.php 86
ERROR - 2021-02-26 01:25:29 --> Severity: Notice --> Undefined variable: userdata C:\xampp\htdocs\senior_care\application\views\admin\view_patient.php 86
ERROR - 2021-02-26 01:25:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\senior_care\application\views\admin\view_patient.php 86
ERROR - 2021-02-26 01:54:17 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\senior_care\application\controllers\Admin.php 34
ERROR - 2021-02-26 02:34:20 --> 404 Page Not Found: Contacthtml/index
ERROR - 2021-02-26 02:36:52 --> 404 Page Not Found: Bloghtml/index
ERROR - 2021-02-26 02:37:32 --> 404 Page Not Found: Testimonialhtml/index
ERROR - 2021-02-26 02:40:31 --> Severity: Notice --> Undefined variable: file_name2 C:\xampp\htdocs\senior_care\application\controllers\Users.php 133
ERROR - 2021-02-26 02:40:32 --> Query error: Column 'reportfile_two' cannot be null - Invalid query: INSERT INTO `userdata` (`register_datetime`, `firstname`, `lastname`, `contact`, `apndate`, `dob`, `age`, `height`, `weight`, `email`, `password`, `medcondition`, `reportfile_one`, `reportfile_two`, `status`) VALUES ('20210226071031', 'jatin', 'Mishra', '8979969678', '2021-02-28', '1944-03-19', '77 years ', '160', '80', 'vibhoranand@gmail.com', '123456', 'Cough and allergies ', 'jatin_20210226071031.jpg', NULL, 0)
ERROR - 2021-02-26 02:55:08 --> Severity: error --> Exception: Too few arguments to function PatientDb::view_patient_recs(), 0 passed in C:\xampp\htdocs\senior_care\application\controllers\Admin.php on line 25 and exactly 1 expected C:\xampp\htdocs\senior_care\application\models\PatientDb.php 36
ERROR - 2021-02-26 06:59:50 --> 404 Page Not Found: U/index
ERROR - 2021-02-26 07:50:46 --> Severity: Compile Error --> Cannot redeclare Users::view_patient_record() C:\xampp\htdocs\senior_care\application\controllers\Users.php 199
ERROR - 2021-02-26 07:51:15 --> Severity: Notice --> Undefined variable: patient_record C:\xampp\htdocs\senior_care\application\views\users\doctor_prescription.php 101
ERROR - 2021-02-26 07:51:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\senior_care\application\views\users\doctor_prescription.php 101
ERROR - 2021-02-26 07:51:43 --> Severity: Notice --> Undefined variable: medrecord C:\xampp\htdocs\senior_care\application\views\users\doctor_prescription.php 101
ERROR - 2021-02-26 07:51:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\senior_care\application\views\users\doctor_prescription.php 101
ERROR - 2021-02-26 08:02:06 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\senior_care\application\views\users\doctor_prescription.php 91
ERROR - 2021-02-26 08:02:06 --> Severity: Notice --> Trying to get property 'firstname' of non-object C:\xampp\htdocs\senior_care\application\views\users\doctor_prescription.php 91
ERROR - 2021-02-26 08:02:06 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\senior_care\application\views\users\doctor_prescription.php 96
ERROR - 2021-02-26 08:02:06 --> Severity: Notice --> Trying to get property 'lastname' of non-object C:\xampp\htdocs\senior_care\application\views\users\doctor_prescription.php 96
ERROR - 2021-02-26 08:02:07 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\senior_care\application\views\users\doctor_prescription.php 101
ERROR - 2021-02-26 08:02:07 --> Severity: Notice --> Trying to get property 'email' of non-object C:\xampp\htdocs\senior_care\application\views\users\doctor_prescription.php 101
ERROR - 2021-02-26 10:01:36 --> Severity: Notice --> Undefined variable: pat_data C:\xampp\htdocs\senior_care\application\views\users\doctor_prescription.php 80
ERROR - 2021-02-26 10:01:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\senior_care\application\views\users\doctor_prescription.php 80
ERROR - 2021-02-26 10:04:15 --> Severity: Notice --> Undefined variable: pat_data C:\xampp\htdocs\senior_care\application\views\users\doctor_prescription.php 80
ERROR - 2021-02-26 10:04:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\senior_care\application\views\users\doctor_prescription.php 80
ERROR - 2021-02-26 10:08:58 --> Severity: Notice --> Undefined variable: pat_data C:\xampp\htdocs\senior_care\application\views\users\doctor_prescription.php 82
ERROR - 2021-02-26 10:08:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\senior_care\application\views\users\doctor_prescription.php 82
ERROR - 2021-02-26 10:09:00 --> Severity: Notice --> Undefined variable: pat_data C:\xampp\htdocs\senior_care\application\views\users\doctor_prescription.php 82
ERROR - 2021-02-26 10:09:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\senior_care\application\views\users\doctor_prescription.php 82
ERROR - 2021-02-26 10:09:01 --> Severity: Notice --> Undefined variable: pat_data C:\xampp\htdocs\senior_care\application\views\users\doctor_prescription.php 82
ERROR - 2021-02-26 10:09:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\senior_care\application\views\users\doctor_prescription.php 82
ERROR - 2021-02-26 10:09:03 --> Severity: Notice --> Undefined variable: pat_data C:\xampp\htdocs\senior_care\application\views\users\doctor_prescription.php 82
ERROR - 2021-02-26 10:09:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\senior_care\application\views\users\doctor_prescription.php 82
ERROR - 2021-02-26 10:09:03 --> Severity: Notice --> Undefined variable: pat_data C:\xampp\htdocs\senior_care\application\views\users\doctor_prescription.php 82
ERROR - 2021-02-26 10:09:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\senior_care\application\views\users\doctor_prescription.php 82
ERROR - 2021-02-26 10:09:03 --> Severity: Notice --> Undefined variable: pat_data C:\xampp\htdocs\senior_care\application\views\users\doctor_prescription.php 82
ERROR - 2021-02-26 10:09:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\senior_care\application\views\users\doctor_prescription.php 82
ERROR - 2021-02-26 10:09:04 --> Severity: Notice --> Undefined variable: pat_data C:\xampp\htdocs\senior_care\application\views\users\doctor_prescription.php 82
ERROR - 2021-02-26 10:09:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\senior_care\application\views\users\doctor_prescription.php 82
ERROR - 2021-02-26 10:09:04 --> Severity: Notice --> Undefined variable: pat_data C:\xampp\htdocs\senior_care\application\views\users\doctor_prescription.php 82
ERROR - 2021-02-26 10:09:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\senior_care\application\views\users\doctor_prescription.php 82
ERROR - 2021-02-26 10:09:04 --> Severity: Notice --> Undefined variable: pat_data C:\xampp\htdocs\senior_care\application\views\users\doctor_prescription.php 82
ERROR - 2021-02-26 10:09:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\senior_care\application\views\users\doctor_prescription.php 82
ERROR - 2021-02-26 10:09:04 --> Severity: Notice --> Undefined variable: pat_data C:\xampp\htdocs\senior_care\application\views\users\doctor_prescription.php 82
ERROR - 2021-02-26 10:09:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\senior_care\application\views\users\doctor_prescription.php 82
ERROR - 2021-02-26 10:09:05 --> Severity: Notice --> Undefined variable: pat_data C:\xampp\htdocs\senior_care\application\views\users\doctor_prescription.php 82
ERROR - 2021-02-26 10:09:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\senior_care\application\views\users\doctor_prescription.php 82
ERROR - 2021-02-26 10:09:07 --> Severity: Notice --> Undefined variable: pat_data C:\xampp\htdocs\senior_care\application\views\users\doctor_prescription.php 82
ERROR - 2021-02-26 10:09:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\senior_care\application\views\users\doctor_prescription.php 82
ERROR - 2021-02-26 10:16:18 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\senior_care\application\views\users\doctor_prescription.php 84
ERROR - 2021-02-26 10:18:17 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\senior_care\application\views\users\doctor_prescription.php 84
