<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-15 05:24:38 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\erp-merging-hub\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2020-09-15 05:24:38 --> Unable to connect to the database
ERROR - 2020-09-15 09:33:13 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 116
ERROR - 2020-09-15 09:33:13 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 138
ERROR - 2020-09-15 09:50:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 120
ERROR - 2020-09-15 09:50:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 142
ERROR - 2020-09-15 09:58:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 120
ERROR - 2020-09-15 09:58:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 142
ERROR - 2020-09-15 10:15:14 --> Severity: error --> Exception: Too few arguments to function Activity::add_activity(), 0 passed in C:\xampp\htdocs\personal-work\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\personal-work\application\controllers\Activity.php 24
ERROR - 2020-09-15 10:18:19 --> Severity: error --> Exception: Too few arguments to function Activity::add_activity(), 0 passed in C:\xampp\htdocs\personal-work\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\personal-work\application\controllers\Activity.php 24
ERROR - 2020-09-15 10:18:22 --> Severity: error --> Exception: Too few arguments to function Activity::add_activity(), 0 passed in C:\xampp\htdocs\personal-work\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\personal-work\application\controllers\Activity.php 24
ERROR - 2020-09-15 10:18:31 --> Severity: error --> Exception: Too few arguments to function Activity::add_activity(), 0 passed in C:\xampp\htdocs\personal-work\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\personal-work\application\controllers\Activity.php 24
ERROR - 2020-09-15 10:19:18 --> Severity: error --> Exception: Too few arguments to function Activity::add_activity(), 0 passed in C:\xampp\htdocs\personal-work\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\personal-work\application\controllers\Activity.php 24
ERROR - 2020-09-15 10:24:31 --> Severity: Notice --> Undefined variable: act_recs C:\xampp\htdocs\personal-work\application\views\admin\activity\add_activity.php 53
ERROR - 2020-09-15 10:24:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\personal-work\application\views\admin\activity\add_activity.php 53
ERROR - 2020-09-15 11:51:38 --> Severity: Notice --> Undefined variable: project_id C:\xampp\htdocs\personal-work\application\controllers\Activity.php 145
ERROR - 2020-09-15 12:29:32 --> Severity: Notice --> Undefined variable: project_id C:\xampp\htdocs\personal-work\application\controllers\Activity.php 145
ERROR - 2020-09-15 12:30:40 --> Severity: Notice --> Undefined variable: project_id C:\xampp\htdocs\personal-work\application\controllers\Activity.php 145
ERROR - 2020-09-15 12:32:12 --> Severity: Notice --> Undefined variable: project_id C:\xampp\htdocs\personal-work\application\controllers\Activity.php 145
ERROR - 2020-09-15 13:53:43 --> Severity: Notice --> Undefined property: Activity::$ApartmentDb C:\xampp\htdocs\personal-work\application\controllers\Activity.php 42
ERROR - 2020-09-15 13:53:43 --> Severity: error --> Exception: Call to a member function view_single_act() on null C:\xampp\htdocs\personal-work\application\controllers\Activity.php 42
ERROR - 2020-09-15 14:05:09 --> Severity: Notice --> Undefined property: CI_Loader::$ApartmentDb C:\xampp\htdocs\personal-work\application\views\admin\activity\view_activity.php 60
ERROR - 2020-09-15 14:05:09 --> Severity: error --> Exception: Call to a member function admin_details() on null C:\xampp\htdocs\personal-work\application\views\admin\activity\view_activity.php 60
ERROR - 2020-09-15 14:23:27 --> Severity: Notice --> Undefined variable: act_list C:\xampp\htdocs\personal-work\application\views\admin\activity\edit_activity.php 54
ERROR - 2020-09-15 14:23:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\personal-work\application\views\admin\activity\edit_activity.php 54
ERROR - 2020-09-15 15:05:02 --> Severity: Notice --> Undefined property: Activity::$ApartmentDb C:\xampp\htdocs\personal-work\application\controllers\Activity.php 53
ERROR - 2020-09-15 15:05:02 --> Severity: error --> Exception: Call to a member function view_single_act() on null C:\xampp\htdocs\personal-work\application\controllers\Activity.php 53
ERROR - 2020-09-15 15:06:07 --> Severity: Notice --> Undefined property: Activity::$ApartmentDb C:\xampp\htdocs\personal-work\application\controllers\Activity.php 53
ERROR - 2020-09-15 15:06:07 --> Severity: error --> Exception: Call to a member function view_single_act() on null C:\xampp\htdocs\personal-work\application\controllers\Activity.php 53
ERROR - 2020-09-15 15:06:09 --> Severity: Notice --> Undefined property: Activity::$ApartmentDb C:\xampp\htdocs\personal-work\application\controllers\Activity.php 53
ERROR - 2020-09-15 15:06:09 --> Severity: error --> Exception: Call to a member function view_single_act() on null C:\xampp\htdocs\personal-work\application\controllers\Activity.php 53
ERROR - 2020-09-15 16:55:55 --> Severity: Notice --> Undefined property: Activity::$ApartmentDb C:\xampp\htdocs\personal-work\application\controllers\Activity.php 200
ERROR - 2020-09-15 16:55:55 --> Severity: error --> Exception: Call to a member function update_act_records() on null C:\xampp\htdocs\personal-work\application\controllers\Activity.php 200
ERROR - 2020-09-15 17:45:29 --> 404 Page Not Found: Activity/delete_act_record
ERROR - 2020-09-15 17:46:43 --> 404 Page Not Found: Activity/delete_act_record
