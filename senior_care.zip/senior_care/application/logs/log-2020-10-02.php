<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-02 06:28:27 --> Query error: Column 'activity_id' cannot be null - Invalid query: INSERT INTO `activity` (`activity_id`, `activity_type`, `activity_description`, `activity_at`, `activity_organization_name`, `start_date`, `end_date`, `participant_count`, `type`, `created_by`, `create_timestamp`, `last_modify_timestamp`, `last_modify_by`, `activity_cancel_reason`) VALUES (NULL, 'Seminar', 'desc seminar', 'College', 'kdk nagpur', '2020-10-02 00:00:00', '2020-10-03 00:00:00', '20', 'Paid', '1', '2020-10-02', '2020-10-02', '1', 0)
ERROR - 2020-10-02 06:29:12 --> Query error: Column 'activity_id' cannot be null - Invalid query: INSERT INTO `activity` (`activity_id`, `activity_type`, `activity_description`, `activity_at`, `activity_organization_name`, `start_date`, `end_date`, `participant_count`, `type`, `created_by`, `create_timestamp`, `last_modify_timestamp`, `last_modify_by`, `activity_cancel_reason`) VALUES (NULL, 'Workshop', 'desc seminar', 'Company', 'feedf', '2020-10-02 00:00:00', '2020-10-03 00:00:00', '75', 'Sponsor', '1', '2020-10-02', '2020-10-02', '1', 0)
ERROR - 2020-10-02 06:29:39 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 326
ERROR - 2020-10-02 06:29:39 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 326
ERROR - 2020-10-02 06:30:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 384
ERROR - 2020-10-02 06:30:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 385
ERROR - 2020-10-02 06:31:21 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 452
ERROR - 2020-10-02 06:31:21 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 453
ERROR - 2020-10-02 06:31:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 384
ERROR - 2020-10-02 06:31:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 385
ERROR - 2020-10-02 08:51:49 --> Query error: Column 'created_by' cannot be null - Invalid query: INSERT INTO `apartment` (`apartment_id`, `member_name`, `reason`, `total_amount`, `remaining_amount`, `created_by`, `create_timestamp`, `last_modify_timestamp`, `last_modify_by`) VALUES ('APT-1012', 'sadsadasd', 'asdsadasd', '3242432', '3242432', NULL, '2020-10-02', '2020-10-02', NULL)
ERROR - 2020-10-02 09:42:39 --> Query error: Column 'created_by' cannot be null - Invalid query: INSERT INTO `apartment` (`apartment_id`, `member_name`, `reason`, `total_amount`, `remaining_amount`, `created_by`, `create_timestamp`, `last_modify_timestamp`, `last_modify_by`) VALUES ('APT-1012', 'shubham', 'qeqw', '0', '0', NULL, '2020-10-02', '2020-10-02', NULL)
ERROR - 2020-10-02 11:34:36 --> Query error: Column 'activity_id' cannot be null - Invalid query: INSERT INTO `activity` (`activity_id`, `activity_type`, `activity_description`, `activity_at`, `activity_organization_name`, `start_date`, `end_date`, `participant_count`, `type`, `created_by`, `create_timestamp`, `last_modify_timestamp`, `last_modify_by`, `activity_cancel_reason`) VALUES (NULL, 'Seminar', ' tdhteht    thr    ere er     erretet', 'College', ' fsfsf  gfd      h rhrtr ', '2020-10-02 00:00:00', '1970-01-01 01:00:00', '20', 'Paid', '1', '2020-10-02', '2020-10-02', '1', 0)
ERROR - 2020-10-02 11:51:36 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 326
ERROR - 2020-10-02 11:51:36 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 326
ERROR - 2020-10-02 11:52:01 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 326
ERROR - 2020-10-02 11:52:01 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 326
ERROR - 2020-10-02 11:52:25 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 326
ERROR - 2020-10-02 11:52:25 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 326
ERROR - 2020-10-02 12:42:41 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 384
ERROR - 2020-10-02 12:42:41 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 385
ERROR - 2020-10-02 12:55:29 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 384
ERROR - 2020-10-02 12:55:29 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 385
ERROR - 2020-10-02 13:07:08 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 384
ERROR - 2020-10-02 13:07:08 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 385
ERROR - 2020-10-02 13:08:21 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 384
ERROR - 2020-10-02 13:08:21 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 385
ERROR - 2020-10-02 13:10:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 385
ERROR - 2020-10-02 13:10:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 386
ERROR - 2020-10-02 13:14:15 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 385
ERROR - 2020-10-02 13:14:15 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 386
ERROR - 2020-10-02 13:14:38 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 385
ERROR - 2020-10-02 13:14:38 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 386
ERROR - 2020-10-02 13:17:29 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 385
ERROR - 2020-10-02 13:17:29 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 386
ERROR - 2020-10-02 13:18:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 385
ERROR - 2020-10-02 13:18:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 386
ERROR - 2020-10-02 13:19:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 385
ERROR - 2020-10-02 13:19:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 386
ERROR - 2020-10-02 15:35:18 --> Query error: Column 'created_by' cannot be null - Invalid query: INSERT INTO `activity` (`activity_id`, `activity_type`, `activity_description`, `activity_at`, `activity_organization_name`, `start_date`, `end_date`, `participant_count`, `type`, `created_by`, `create_timestamp`, `last_modify_timestamp`, `last_modify_by`, `activity_cancel_reason`) VALUES ('ACT-1001', 'Seminar', 'test semi', 'College', 'kdk', '2020-10-02 00:00:00', '2020-10-03 00:00:00', '9', 'Paid', NULL, '2020-10-02', '2020-10-02', NULL, 0)
ERROR - 2020-10-02 17:09:44 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 327
ERROR - 2020-10-02 17:09:44 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 327
ERROR - 2020-10-02 17:11:17 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 385
ERROR - 2020-10-02 17:11:17 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 386
ERROR - 2020-10-02 17:12:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 385
ERROR - 2020-10-02 17:12:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 386
ERROR - 2020-10-02 17:28:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 385
ERROR - 2020-10-02 17:28:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 386
ERROR - 2020-10-02 17:29:49 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 327
ERROR - 2020-10-02 17:29:50 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 327
ERROR - 2020-10-02 17:30:21 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 385
ERROR - 2020-10-02 17:30:21 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 386
ERROR - 2020-10-02 17:30:41 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 385
ERROR - 2020-10-02 17:30:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 386
