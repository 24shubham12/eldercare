<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-12 10:58:15 --> Severity: error --> Exception: Unable to locate the model you have specified: UgDb C:\xampp\htdocs\php_codeigniter\system\core\Loader.php 348
ERROR - 2020-10-12 10:58:16 --> Severity: error --> Exception: Unable to locate the model you have specified: UgDb C:\xampp\htdocs\php_codeigniter\system\core\Loader.php 348
ERROR - 2020-10-12 10:58:42 --> Severity: error --> Exception: Unable to locate the model you have specified: UgDb C:\xampp\htdocs\php_codeigniter\system\core\Loader.php 348
