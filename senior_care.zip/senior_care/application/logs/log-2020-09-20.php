<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-20 11:56:55 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\personal-work\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2020-09-20 11:56:55 --> Unable to connect to the database
ERROR - 2020-09-20 12:33:04 --> Query error: Unknown column 'total_fees' in 'field list' - Invalid query: UPDATE `activity` SET `activity_type` = 'Event', `total_fees` = '2000'
WHERE `act_id` = '17'
ERROR - 2020-09-20 12:57:29 --> Severity: Warning --> Use of undefined constant Sponsor - assumed 'Sponsor' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 198
ERROR - 2020-09-20 12:57:29 --> Severity: Warning --> Use of undefined constant Sponsor - assumed 'Sponsor' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 206
ERROR - 2020-09-20 12:57:29 --> Severity: Warning --> Use of undefined constant Sponsor - assumed 'Sponsor' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 198
ERROR - 2020-09-20 12:57:29 --> Severity: Warning --> Use of undefined constant Sponsor - assumed 'Sponsor' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 206
ERROR - 2020-09-20 12:59:20 --> Severity: Warning --> Use of undefined constant Sponsor - assumed 'Sponsor' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 198
ERROR - 2020-09-20 12:59:20 --> Severity: Warning --> Use of undefined constant Sponsor - assumed 'Sponsor' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 206
ERROR - 2020-09-20 12:59:20 --> Severity: Warning --> Use of undefined constant Sponsor - assumed 'Sponsor' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 198
ERROR - 2020-09-20 12:59:20 --> Severity: Warning --> Use of undefined constant Sponsor - assumed 'Sponsor' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 206
ERROR - 2020-09-20 12:59:29 --> Severity: Warning --> Use of undefined constant Sponsor - assumed 'Sponsor' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 198
ERROR - 2020-09-20 12:59:29 --> Severity: Warning --> Use of undefined constant Sponsor - assumed 'Sponsor' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 206
ERROR - 2020-09-20 12:59:29 --> Severity: Warning --> Use of undefined constant Sponsor - assumed 'Sponsor' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 198
ERROR - 2020-09-20 12:59:29 --> Severity: Warning --> Use of undefined constant Sponsor - assumed 'Sponsor' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 206
ERROR - 2020-09-20 13:18:29 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 13:18:29 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 13:18:29 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 13:18:29 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 13:43:32 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 201
ERROR - 2020-09-20 13:43:37 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 201
ERROR - 2020-09-20 13:43:41 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 201
ERROR - 2020-09-20 13:44:38 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 209
ERROR - 2020-09-20 13:48:27 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 13:48:27 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 13:48:27 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 13:48:27 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 13:54:12 --> Query error: Unknown column 'total_fees' in 'field list' - Invalid query: UPDATE `activity` SET `total_fees` = '4000'
WHERE `act_id` = '1'
ERROR - 2020-09-20 13:55:16 --> Query error: Unknown column 'total_fees' in 'field list' - Invalid query: UPDATE `activity` SET `total_fees` = '4000'
WHERE `act_id` = '1'
ERROR - 2020-09-20 13:58:03 --> Query error: Unknown column 'total_fees' in 'field list' - Invalid query: UPDATE `activity` SET `total_fees` = '4000'
WHERE `act_id` = '1'
ERROR - 2020-09-20 14:10:40 --> Severity: Notice --> Undefined property: stdClass::$total_amount C:\xampp\htdocs\personal-work\application\controllers\Activity.php 459
ERROR - 2020-09-20 14:16:34 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 14:16:34 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 14:16:34 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 14:16:34 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 14:19:29 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 14:19:29 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 14:19:29 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 14:19:29 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 14:21:07 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 14:21:07 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 14:21:07 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 14:21:07 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 14:23:57 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 14:23:57 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 14:23:57 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 14:23:57 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 14:27:18 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 464
ERROR - 2020-09-20 14:27:18 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 465
ERROR - 2020-09-20 14:27:27 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 14:27:27 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 14:27:27 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 14:27:27 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 14:29:21 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 14:29:21 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 14:29:21 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 14:29:21 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 14:31:35 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 14:31:35 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 14:31:35 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 14:31:35 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 15:29:36 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 15:29:36 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 15:29:36 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 15:29:37 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 15:31:35 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 15:31:35 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 15:31:35 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 15:31:35 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 15:34:19 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 15:34:19 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 15:34:19 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 15:34:19 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 15:36:08 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 15:36:08 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 15:36:08 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 15:36:08 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 15:40:34 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 15:40:34 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 15:40:34 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 15:40:34 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 15:40:46 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 15:40:46 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 15:40:46 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 15:40:46 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 16:10:55 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 16:10:55 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 16:10:55 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 16:10:55 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 16:41:04 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 465
ERROR - 2020-09-20 16:41:04 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 466
ERROR - 2020-09-20 16:42:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 465
ERROR - 2020-09-20 16:42:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 466
ERROR - 2020-09-20 16:43:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 465
ERROR - 2020-09-20 16:43:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 466
ERROR - 2020-09-20 16:44:32 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 465
ERROR - 2020-09-20 16:44:32 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 466
ERROR - 2020-09-20 16:45:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 465
ERROR - 2020-09-20 16:45:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 466
ERROR - 2020-09-20 16:48:29 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 16:48:29 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 16:48:29 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 16:48:29 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 274
ERROR - 2020-09-20 16:54:55 --> Severity: Notice --> Undefined variable: apt C:\xampp\htdocs\personal-work\application\views\admin\activity\add_payment.php 390
ERROR - 2020-09-20 16:54:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\personal-work\application\views\admin\activity\add_payment.php 390
ERROR - 2020-09-20 16:59:19 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\personal-work\application\views\admin\activity\add_payment.php 575
ERROR - 2020-09-20 16:59:23 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\personal-work\application\views\admin\activity\add_payment.php 575
ERROR - 2020-09-20 19:06:16 --> Severity: error --> Exception: Call to undefined method ActivityDb::activity_fees() C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 84
ERROR - 2020-09-20 19:07:35 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 279
ERROR - 2020-09-20 19:07:35 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 279
ERROR - 2020-09-20 19:07:35 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 279
ERROR - 2020-09-20 19:07:35 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 279
ERROR - 2020-09-20 19:33:01 --> Severity: error --> Exception: Too few arguments to function Activity::view_payment(), 0 passed in C:\xampp\htdocs\personal-work\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\personal-work\application\controllers\Activity.php 101
ERROR - 2020-09-20 19:36:05 --> Severity: error --> Exception: Too few arguments to function Activity::view_payment(), 0 passed in C:\xampp\htdocs\personal-work\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\personal-work\application\controllers\Activity.php 101
ERROR - 2020-09-20 19:36:52 --> Severity: error --> Exception: Too few arguments to function Activity::view_payment(), 0 passed in C:\xampp\htdocs\personal-work\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\personal-work\application\controllers\Activity.php 101
ERROR - 2020-09-20 19:37:13 --> Severity: Compile Error --> Redefinition of parameter $id C:\xampp\htdocs\personal-work\application\controllers\Activity.php 101
ERROR - 2020-09-20 19:37:22 --> Severity: error --> Exception: Too few arguments to function Activity::view_payment(), 0 passed in C:\xampp\htdocs\personal-work\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\personal-work\application\controllers\Activity.php 101
ERROR - 2020-09-20 19:37:32 --> Severity: error --> Exception: Too few arguments to function Activity::view_payment(), 0 passed in C:\xampp\htdocs\personal-work\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\personal-work\application\controllers\Activity.php 101
ERROR - 2020-09-20 19:37:34 --> Severity: error --> Exception: Too few arguments to function Activity::view_payment(), 0 passed in C:\xampp\htdocs\personal-work\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\personal-work\application\controllers\Activity.php 101
ERROR - 2020-09-20 19:37:34 --> Severity: error --> Exception: Too few arguments to function Activity::view_payment(), 0 passed in C:\xampp\htdocs\personal-work\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\personal-work\application\controllers\Activity.php 101
ERROR - 2020-09-20 19:37:34 --> Severity: error --> Exception: Too few arguments to function Activity::view_payment(), 0 passed in C:\xampp\htdocs\personal-work\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\personal-work\application\controllers\Activity.php 101
ERROR - 2020-09-20 19:37:35 --> Severity: error --> Exception: Too few arguments to function Activity::view_payment(), 0 passed in C:\xampp\htdocs\personal-work\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\personal-work\application\controllers\Activity.php 101
ERROR - 2020-09-20 19:37:35 --> Severity: error --> Exception: Too few arguments to function Activity::view_payment(), 0 passed in C:\xampp\htdocs\personal-work\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\personal-work\application\controllers\Activity.php 101
ERROR - 2020-09-20 19:37:35 --> Severity: error --> Exception: Too few arguments to function Activity::view_payment(), 0 passed in C:\xampp\htdocs\personal-work\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\personal-work\application\controllers\Activity.php 101
ERROR - 2020-09-20 19:38:51 --> Severity: error --> Exception: Too few arguments to function Activity::view_payment(), 0 passed in C:\xampp\htdocs\personal-work\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\personal-work\application\controllers\Activity.php 101
ERROR - 2020-09-20 19:38:53 --> Severity: error --> Exception: Too few arguments to function Activity::view_payment(), 0 passed in C:\xampp\htdocs\personal-work\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\personal-work\application\controllers\Activity.php 101
ERROR - 2020-09-20 19:38:54 --> Severity: error --> Exception: Too few arguments to function Activity::view_payment(), 0 passed in C:\xampp\htdocs\personal-work\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\personal-work\application\controllers\Activity.php 101
ERROR - 2020-09-20 19:38:54 --> Severity: error --> Exception: Too few arguments to function Activity::view_payment(), 0 passed in C:\xampp\htdocs\personal-work\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\personal-work\application\controllers\Activity.php 101
ERROR - 2020-09-20 19:38:54 --> Severity: error --> Exception: Too few arguments to function Activity::view_payment(), 0 passed in C:\xampp\htdocs\personal-work\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\personal-work\application\controllers\Activity.php 101
ERROR - 2020-09-20 19:38:54 --> Severity: error --> Exception: Too few arguments to function Activity::view_payment(), 0 passed in C:\xampp\htdocs\personal-work\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\personal-work\application\controllers\Activity.php 101
ERROR - 2020-09-20 19:45:01 --> Severity: error --> Exception: Too few arguments to function Activity::view_payment(), 0 passed in C:\xampp\htdocs\personal-work\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\personal-work\application\controllers\Activity.php 101
ERROR - 2020-09-20 19:45:03 --> Severity: error --> Exception: Too few arguments to function Activity::view_payment(), 0 passed in C:\xampp\htdocs\personal-work\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\personal-work\application\controllers\Activity.php 101
ERROR - 2020-09-20 19:45:03 --> Severity: error --> Exception: Too few arguments to function Activity::view_payment(), 0 passed in C:\xampp\htdocs\personal-work\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\personal-work\application\controllers\Activity.php 101
ERROR - 2020-09-20 19:45:04 --> Severity: error --> Exception: Too few arguments to function Activity::view_payment(), 0 passed in C:\xampp\htdocs\personal-work\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\personal-work\application\controllers\Activity.php 101
ERROR - 2020-09-20 19:45:04 --> Severity: error --> Exception: Too few arguments to function Activity::view_payment(), 0 passed in C:\xampp\htdocs\personal-work\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\personal-work\application\controllers\Activity.php 101
