<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-30 12:03:38 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\personal-work\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2020-09-30 12:03:38 --> Unable to connect to the database
