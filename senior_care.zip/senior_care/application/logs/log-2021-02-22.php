<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-22 11:37:59 --> 404 Page Not Found: Users/Home
ERROR - 2021-02-22 16:03:38 --> 404 Page Not Found: Serviceshtml/index
ERROR - 2021-02-22 18:39:21 --> 404 Page Not Found: Serviceshtml/index
