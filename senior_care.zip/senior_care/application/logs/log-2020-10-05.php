<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-05 06:11:22 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\perso-work\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2020-10-05 06:11:22 --> Unable to connect to the database
ERROR - 2020-10-05 06:11:42 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\perso-work\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2020-10-05 06:11:42 --> Unable to connect to the database
ERROR - 2020-10-05 06:12:23 --> Severity: Notice --> Undefined variable: act_fees C:\xampp\htdocs\perso-work\application\views\admin\activity\manage_activity.php 106
ERROR - 2020-10-05 06:12:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\perso-work\application\views\admin\activity\manage_activity.php 106
ERROR - 2020-10-05 06:12:23 --> Severity: Notice --> Undefined variable: act_fees C:\xampp\htdocs\perso-work\application\views\admin\activity\manage_activity.php 106
ERROR - 2020-10-05 06:12:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\perso-work\application\views\admin\activity\manage_activity.php 106
ERROR - 2020-10-05 06:14:04 --> Severity: Notice --> Undefined variable: act_fees C:\xampp\htdocs\perso-work\application\views\admin\activity\manage_activity.php 106
ERROR - 2020-10-05 06:14:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\perso-work\application\views\admin\activity\manage_activity.php 106
ERROR - 2020-10-05 06:14:04 --> Severity: Notice --> Undefined variable: act_fees C:\xampp\htdocs\perso-work\application\views\admin\activity\manage_activity.php 106
ERROR - 2020-10-05 06:14:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\perso-work\application\views\admin\activity\manage_activity.php 106
ERROR - 2020-10-05 06:19:04 --> Severity: Notice --> Undefined variable: act_fees C:\xampp\htdocs\perso-work\application\views\admin\activity\manage_activity.php 106
ERROR - 2020-10-05 06:19:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\perso-work\application\views\admin\activity\manage_activity.php 106
ERROR - 2020-10-05 06:20:03 --> Severity: Notice --> Undefined variable: act_fees C:\xampp\htdocs\perso-work\application\views\admin\activity\manage_activity.php 107
ERROR - 2020-10-05 06:20:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\perso-work\application\views\admin\activity\manage_activity.php 107
ERROR - 2020-10-05 06:20:49 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\perso-work\application\views\admin\activity\add_fees.php 327
ERROR - 2020-10-05 06:20:49 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\perso-work\application\views\admin\activity\add_fees.php 327
ERROR - 2020-10-05 06:26:44 --> Severity: Notice --> Undefined variable: act_fees C:\xampp\htdocs\perso-work\application\views\admin\activity\manage_activity.php 107
ERROR - 2020-10-05 06:26:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\perso-work\application\views\admin\activity\manage_activity.php 107
ERROR - 2020-10-05 06:29:33 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\perso-work\application\views\admin\activity\add_fees.php 327
ERROR - 2020-10-05 06:29:33 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\perso-work\application\views\admin\activity\add_fees.php 327
ERROR - 2020-10-05 06:45:58 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\perso-work\application\views\admin\activity\add_fees.php 327
ERROR - 2020-10-05 06:45:58 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\perso-work\application\views\admin\activity\add_fees.php 327
ERROR - 2020-10-05 06:54:20 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\perso-work\application\views\admin\activity\add_fees.php 327
ERROR - 2020-10-05 06:54:20 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\perso-work\application\views\admin\activity\add_fees.php 327
ERROR - 2020-10-05 06:54:49 --> Query error: Unknown column 'paid_amount' in 'field list' - Invalid query: UPDATE `activity_transaction` SET `paid_amount` = 0, `remaining_amount` = 1000
WHERE `activity_transc_id` = '6'
ERROR - 2020-10-05 06:58:54 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\perso-work\application\views\admin\activity\add_fees.php 327
ERROR - 2020-10-05 06:58:54 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\perso-work\application\views\admin\activity\add_fees.php 327
ERROR - 2020-10-05 07:04:48 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\perso-work\application\views\admin\activity\add_fees.php 327
ERROR - 2020-10-05 07:04:48 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\perso-work\application\views\admin\activity\add_fees.php 327
ERROR - 2020-10-05 07:06:40 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\perso-work\application\views\admin\activity\add_fees.php 327
ERROR - 2020-10-05 07:06:40 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\perso-work\application\views\admin\activity\add_fees.php 327
