<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-23 07:02:06 --> 404 Page Not Found: Register/index
ERROR - 2021-02-23 07:02:11 --> 404 Page Not Found: Registeration/index
ERROR - 2021-02-23 07:02:30 --> 404 Page Not Found: Registration/index
ERROR - 2021-02-23 07:03:10 --> 404 Page Not Found: Registration/index
ERROR - 2021-02-23 07:06:30 --> 404 Page Not Found: Registration/index
ERROR - 2021-02-23 11:13:15 --> 404 Page Not Found: Login/index
ERROR - 2021-02-23 19:10:18 --> 404 Page Not Found: Asset/images
ERROR - 2021-02-23 19:10:21 --> 404 Page Not Found: Asset/images
