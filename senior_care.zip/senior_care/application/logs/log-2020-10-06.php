<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-06 05:51:05 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\perso-work\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2020-10-06 05:51:05 --> Unable to connect to the database
ERROR - 2020-10-06 05:51:18 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\perso-work\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2020-10-06 05:51:18 --> Unable to connect to the database
ERROR - 2020-10-06 07:58:47 --> Severity: error --> Exception: Unable to locate the model you have specified: PhdDb C:\xampp\htdocs\perso-work\system\core\Loader.php 348
ERROR - 2020-10-06 08:43:25 --> Severity: error --> Exception: Unable to locate the model you have specified: PhdDb C:\xampp\htdocs\perso-work\system\core\Loader.php 348
ERROR - 2020-10-06 08:44:16 --> Severity: error --> Exception: Call to undefined method InternDb::fetch_all_payment_trans() C:\xampp\htdocs\perso-work\application\controllers\Transaction.php 28
ERROR - 2020-10-06 09:52:59 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\perso-work\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2020-10-06 09:52:59 --> Unable to connect to the database
