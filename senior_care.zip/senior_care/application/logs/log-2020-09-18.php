<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-18 09:53:17 --> Query error: Column 'created_by' cannot be null - Invalid query: INSERT INTO `activity_fees` (`act_id`, `total_fees`, `created_by`, `create_timestamp`, `last_modify_timestamp`, `last_modify_by`, `activity_cancel`) VALUES ('1', '3000', NULL, '20200918132317', '20200918132317', NULL, 0)
ERROR - 2020-09-18 09:58:57 --> Severity: error --> Exception: Too few arguments to function Activity::add_fees(), 0 passed in C:\xampp\htdocs\personal-work\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\personal-work\application\controllers\Activity.php 71
ERROR - 2020-09-18 10:01:03 --> Severity: error --> Exception: Too few arguments to function Activity::add_fees(), 0 passed in C:\xampp\htdocs\personal-work\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\personal-work\application\controllers\Activity.php 71
ERROR - 2020-09-18 10:01:08 --> Severity: error --> Exception: Too few arguments to function Activity::add_fees(), 0 passed in C:\xampp\htdocs\personal-work\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\personal-work\application\controllers\Activity.php 71
ERROR - 2020-09-18 11:12:30 --> Query error: Unknown column 'total_fees' in 'field list' - Invalid query: UPDATE `activity` SET `activity_type` = 'Workshop', `total_fees` = '1500'
WHERE `act_id` = '5'
ERROR - 2020-09-18 15:36:08 --> Query error: Column 'created_by' cannot be null - Invalid query: INSERT INTO `activity_transaction` (`act_id`, `currentpay_amount`, `payment_mode`, `create_timestamp`, `account_holder_name`, `bank_name`, `cheque_number`, `ifsc_code`, `branch_name`, `upi_transaction_id`, `transaction_name`, `transaction_mobile`, `google_transaction_id`, `bank_transaction_id`, `created_by`, `last_modify_timestamp`, `last_modify_by`, `transc_cancel_status`, `transc_cancel_reason`) VALUES ('1', '1000', 'Cash', '2020-09-18', '', '', '', '', '', '', '', '', '', '', NULL, '2020-09-18', NULL, 0, '')
ERROR - 2020-09-18 15:37:08 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 465
ERROR - 2020-09-18 15:37:08 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 466
ERROR - 2020-09-18 15:40:21 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 465
ERROR - 2020-09-18 15:40:21 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 466
ERROR - 2020-09-18 16:00:10 --> Query error: Unknown column 'total_fees' in 'field list' - Invalid query: UPDATE `activity` SET `activity_type` = 'Seminar', `total_fees` = '2000'
WHERE `act_id` = '9'
ERROR - 2020-09-18 16:01:01 --> Query error: Unknown column 'total_fees' in 'field list' - Invalid query: UPDATE `activity` SET `activity_type` = 'Workshop', `total_fees` = '50000000'
WHERE `act_id` = '14'
ERROR - 2020-09-18 16:05:46 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 465
ERROR - 2020-09-18 16:05:46 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 466
