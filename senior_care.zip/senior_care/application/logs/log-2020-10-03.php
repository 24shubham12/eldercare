<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-03 06:38:50 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 327
ERROR - 2020-10-03 06:38:50 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 327
ERROR - 2020-10-03 06:44:15 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 327
ERROR - 2020-10-03 06:44:15 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 327
ERROR - 2020-10-03 07:02:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 453
ERROR - 2020-10-03 07:02:24 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 454
