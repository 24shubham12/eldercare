<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-19 06:43:05 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\personal-work\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2020-09-19 06:43:05 --> Unable to connect to the database
ERROR - 2020-09-19 06:43:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\personal-work\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2020-09-19 06:43:08 --> Unable to connect to the database
ERROR - 2020-09-19 08:08:31 --> Severity: Notice --> Undefined property: stdClass::$activity_type C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 76
ERROR - 2020-09-19 08:08:31 --> Severity: Notice --> Undefined property: stdClass::$activity_id C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 110
ERROR - 2020-09-19 08:08:31 --> Severity: Notice --> Undefined property: stdClass::$activity_type C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 76
ERROR - 2020-09-19 08:08:31 --> Severity: Notice --> Undefined property: stdClass::$activity_id C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 110
ERROR - 2020-09-19 08:08:31 --> Severity: Notice --> Undefined property: stdClass::$activity_type C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 76
ERROR - 2020-09-19 08:08:31 --> Severity: Notice --> Undefined property: stdClass::$activity_id C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 110
ERROR - 2020-09-19 08:08:31 --> Severity: Notice --> Undefined property: stdClass::$activity_type C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 76
ERROR - 2020-09-19 08:08:31 --> Severity: Notice --> Undefined property: stdClass::$activity_id C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 110
ERROR - 2020-09-19 08:08:31 --> Severity: Notice --> Undefined property: stdClass::$activity_type C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 76
ERROR - 2020-09-19 08:08:31 --> Severity: Notice --> Undefined property: stdClass::$activity_id C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 110
ERROR - 2020-09-19 08:10:22 --> Severity: Notice --> Undefined property: stdClass::$total_fees C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 120
ERROR - 2020-09-19 08:10:22 --> Severity: Notice --> Undefined property: stdClass::$total_fees C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 120
ERROR - 2020-09-19 08:10:22 --> Severity: Notice --> Undefined property: stdClass::$total_fees C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 120
ERROR - 2020-09-19 08:11:46 --> Severity: Notice --> Undefined property: stdClass::$total_fees C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 128
ERROR - 2020-09-19 08:11:46 --> Severity: Notice --> Undefined property: stdClass::$total_fees C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 128
ERROR - 2020-09-19 08:11:46 --> Severity: Notice --> Undefined property: stdClass::$total_fees C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 128
ERROR - 2020-09-19 08:11:46 --> Severity: Notice --> Undefined property: stdClass::$total_fees C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 128
ERROR - 2020-09-19 08:11:46 --> Severity: Notice --> Undefined property: stdClass::$total_fees C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 128
ERROR - 2020-09-19 08:11:46 --> Severity: Notice --> Undefined property: stdClass::$total_fees C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 128
ERROR - 2020-09-19 08:11:46 --> Severity: Notice --> Undefined property: stdClass::$total_fees C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 128
ERROR - 2020-09-19 08:11:46 --> Severity: Notice --> Undefined property: stdClass::$total_fees C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 128
ERROR - 2020-09-19 08:11:46 --> Severity: Notice --> Undefined property: stdClass::$total_fees C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 128
ERROR - 2020-09-19 08:11:46 --> Severity: Notice --> Undefined property: stdClass::$total_fees C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 128
ERROR - 2020-09-19 08:11:46 --> Severity: Notice --> Undefined property: stdClass::$total_fees C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 128
ERROR - 2020-09-19 08:11:46 --> Severity: Notice --> Undefined property: stdClass::$total_fees C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 128
ERROR - 2020-09-19 08:11:46 --> Severity: Notice --> Undefined property: stdClass::$total_fees C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 128
ERROR - 2020-09-19 08:11:46 --> Severity: Notice --> Undefined property: stdClass::$total_fees C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 128
ERROR - 2020-09-19 08:11:46 --> Severity: Notice --> Undefined property: stdClass::$total_fees C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 128
ERROR - 2020-09-19 08:14:33 --> Severity: Notice --> Undefined property: stdClass::$total_fees C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 128
ERROR - 2020-09-19 08:14:33 --> Severity: Notice --> Undefined property: stdClass::$total_fees C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 128
ERROR - 2020-09-19 08:14:33 --> Severity: Notice --> Undefined property: stdClass::$total_fees C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 128
ERROR - 2020-09-19 08:14:33 --> Severity: Notice --> Undefined property: stdClass::$total_fees C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 128
ERROR - 2020-09-19 08:14:33 --> Severity: Notice --> Undefined property: stdClass::$total_fees C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 128
ERROR - 2020-09-19 08:14:33 --> Severity: Notice --> Undefined property: stdClass::$total_fees C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 128
ERROR - 2020-09-19 08:14:33 --> Severity: Notice --> Undefined property: stdClass::$total_fees C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 128
ERROR - 2020-09-19 08:14:33 --> Severity: Notice --> Undefined property: stdClass::$total_fees C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 128
ERROR - 2020-09-19 08:14:33 --> Severity: Notice --> Undefined property: stdClass::$total_fees C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 128
ERROR - 2020-09-19 08:14:33 --> Severity: Notice --> Undefined property: stdClass::$total_fees C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 128
ERROR - 2020-09-19 08:14:33 --> Severity: Notice --> Undefined property: stdClass::$total_fees C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 128
ERROR - 2020-09-19 08:14:33 --> Severity: Notice --> Undefined property: stdClass::$total_fees C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 128
ERROR - 2020-09-19 08:14:33 --> Severity: Notice --> Undefined property: stdClass::$total_fees C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 128
ERROR - 2020-09-19 08:14:33 --> Severity: Notice --> Undefined property: stdClass::$total_fees C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 128
ERROR - 2020-09-19 08:14:33 --> Severity: Notice --> Undefined property: stdClass::$total_fees C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 128
ERROR - 2020-09-19 08:15:41 --> Severity: Notice --> Undefined property: stdClass::$activity_id C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 118
ERROR - 2020-09-19 08:15:41 --> Severity: Notice --> Undefined property: stdClass::$activity_id C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 118
ERROR - 2020-09-19 08:15:41 --> Severity: Notice --> Undefined property: stdClass::$activity_id C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 118
ERROR - 2020-09-19 08:15:41 --> Severity: Notice --> Undefined property: stdClass::$activity_id C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 118
ERROR - 2020-09-19 08:15:41 --> Severity: Notice --> Undefined property: stdClass::$activity_id C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 118
ERROR - 2020-09-19 08:15:41 --> Severity: Notice --> Undefined property: stdClass::$activity_id C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 118
ERROR - 2020-09-19 08:15:41 --> Severity: Notice --> Undefined property: stdClass::$activity_id C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 118
ERROR - 2020-09-19 08:15:41 --> Severity: Notice --> Undefined property: stdClass::$activity_id C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 118
ERROR - 2020-09-19 08:15:42 --> Severity: Notice --> Undefined property: stdClass::$activity_id C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 118
ERROR - 2020-09-19 08:15:42 --> Severity: Notice --> Undefined property: stdClass::$activity_id C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 118
ERROR - 2020-09-19 08:15:42 --> Severity: Notice --> Undefined property: stdClass::$activity_id C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 118
ERROR - 2020-09-19 08:15:42 --> Severity: Notice --> Undefined property: stdClass::$activity_id C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 118
ERROR - 2020-09-19 08:15:42 --> Severity: Notice --> Undefined property: stdClass::$activity_id C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 118
ERROR - 2020-09-19 08:15:42 --> Severity: Notice --> Undefined property: stdClass::$activity_id C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 118
ERROR - 2020-09-19 08:15:42 --> Severity: Notice --> Undefined property: stdClass::$activity_id C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 118
ERROR - 2020-09-19 08:21:34 --> Severity: Notice --> Undefined property: stdClass::$activity_cancel_reason C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 145
ERROR - 2020-09-19 08:21:34 --> Severity: Notice --> Undefined property: stdClass::$activity_cancel_reason C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 145
ERROR - 2020-09-19 08:21:34 --> Severity: Notice --> Undefined property: stdClass::$activity_cancel_reason C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 145
ERROR - 2020-09-19 08:21:34 --> Severity: Notice --> Undefined property: stdClass::$activity_cancel_reason C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 145
ERROR - 2020-09-19 08:21:34 --> Severity: Notice --> Undefined property: stdClass::$activity_cancel_reason C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 145
ERROR - 2020-09-19 08:21:34 --> Severity: Notice --> Undefined property: stdClass::$activity_cancel_reason C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 145
ERROR - 2020-09-19 08:21:34 --> Severity: Notice --> Undefined property: stdClass::$activity_cancel_reason C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 145
ERROR - 2020-09-19 08:21:34 --> Severity: Notice --> Undefined property: stdClass::$activity_cancel_reason C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 145
ERROR - 2020-09-19 08:21:34 --> Severity: Notice --> Undefined property: stdClass::$activity_cancel_reason C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 145
ERROR - 2020-09-19 08:21:34 --> Severity: Notice --> Undefined property: stdClass::$activity_cancel_reason C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 145
ERROR - 2020-09-19 08:21:34 --> Severity: Notice --> Undefined property: stdClass::$activity_cancel_reason C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 145
ERROR - 2020-09-19 08:21:34 --> Severity: Notice --> Undefined property: stdClass::$activity_cancel_reason C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 145
ERROR - 2020-09-19 08:21:34 --> Severity: Notice --> Undefined property: stdClass::$activity_cancel_reason C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 145
ERROR - 2020-09-19 08:21:34 --> Severity: Notice --> Undefined property: stdClass::$activity_cancel_reason C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 145
ERROR - 2020-09-19 08:21:34 --> Severity: Notice --> Undefined property: stdClass::$activity_cancel_reason C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 145
ERROR - 2020-09-19 09:05:00 --> Severity: error --> Exception: Call to undefined method ActivityDb::activity_fees() C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 71
ERROR - 2020-09-19 09:07:22 --> Severity: error --> Exception: Call to undefined method ActivityDb::activity_fees() C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 71
ERROR - 2020-09-19 09:08:36 --> Severity: error --> Exception: Call to undefined method ActivityDb::activity_fees() C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 55
ERROR - 2020-09-19 09:30:39 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 133
ERROR - 2020-09-19 09:30:39 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 143
ERROR - 2020-09-19 09:30:39 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 153
ERROR - 2020-09-19 09:30:39 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 133
ERROR - 2020-09-19 09:30:39 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 143
ERROR - 2020-09-19 09:30:39 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 153
ERROR - 2020-09-19 09:30:39 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 133
ERROR - 2020-09-19 09:30:39 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 143
ERROR - 2020-09-19 09:30:39 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 153
ERROR - 2020-09-19 09:33:12 --> Severity: error --> Exception: Too few arguments to function Activity::manage_activity(), 0 passed in C:\xampp\htdocs\personal-work\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\personal-work\application\controllers\Activity.php 61
ERROR - 2020-09-19 09:34:23 --> Severity: error --> Exception: Too few arguments to function Activity::manage_activity(), 0 passed in C:\xampp\htdocs\personal-work\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\personal-work\application\controllers\Activity.php 61
ERROR - 2020-09-19 09:35:08 --> Severity: error --> Exception: Too few arguments to function Activity::manage_activity(), 0 passed in C:\xampp\htdocs\personal-work\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\personal-work\application\controllers\Activity.php 61
ERROR - 2020-09-19 10:22:48 --> Severity: Notice --> Undefined variable: act_fees_rec C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 54
ERROR - 2020-09-19 10:22:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 54
ERROR - 2020-09-19 10:22:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 81
ERROR - 2020-09-19 10:23:15 --> Severity: Notice --> Undefined variable: act_fees_rec C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 54
ERROR - 2020-09-19 10:23:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 54
ERROR - 2020-09-19 10:32:34 --> Severity: Notice --> Undefined variable: ttl_fees C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 134
ERROR - 2020-09-19 10:32:34 --> Severity: Notice --> Undefined variable: rem_fees C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 144
ERROR - 2020-09-19 10:32:34 --> Severity: Notice --> Undefined variable: paid_fees C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 154
ERROR - 2020-09-19 10:32:34 --> Severity: Notice --> Undefined variable: ttl_fees C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 134
ERROR - 2020-09-19 10:32:34 --> Severity: Notice --> Undefined variable: rem_fees C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 144
ERROR - 2020-09-19 10:32:34 --> Severity: Notice --> Undefined variable: paid_fees C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 154
ERROR - 2020-09-19 10:32:34 --> Severity: Notice --> Undefined variable: ttl_fees C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 134
ERROR - 2020-09-19 10:32:34 --> Severity: Notice --> Undefined variable: rem_fees C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 144
ERROR - 2020-09-19 10:32:34 --> Severity: Notice --> Undefined variable: paid_fees C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 154
ERROR - 2020-09-19 10:32:43 --> Severity: Notice --> Undefined variable: ttl_fees C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 133
ERROR - 2020-09-19 10:32:43 --> Severity: Notice --> Undefined variable: rem_fees C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 143
ERROR - 2020-09-19 10:32:43 --> Severity: Notice --> Undefined variable: paid_fees C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 153
ERROR - 2020-09-19 10:32:43 --> Severity: Notice --> Undefined variable: ttl_fees C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 133
ERROR - 2020-09-19 10:32:43 --> Severity: Notice --> Undefined variable: rem_fees C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 143
ERROR - 2020-09-19 10:32:43 --> Severity: Notice --> Undefined variable: paid_fees C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 153
ERROR - 2020-09-19 10:32:43 --> Severity: Notice --> Undefined variable: ttl_fees C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 133
ERROR - 2020-09-19 10:32:43 --> Severity: Notice --> Undefined variable: rem_fees C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 143
ERROR - 2020-09-19 10:32:43 --> Severity: Notice --> Undefined variable: paid_fees C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 153
ERROR - 2020-09-19 10:32:57 --> Severity: Notice --> Undefined variable: act_fees_rec C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 54
ERROR - 2020-09-19 10:32:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 54
ERROR - 2020-09-19 10:45:26 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 139
ERROR - 2020-09-19 10:45:26 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 139
ERROR - 2020-09-19 10:45:26 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 139
ERROR - 2020-09-19 10:52:36 --> Severity: Notice --> Undefined property: stdClass::$total_amount C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 135
ERROR - 2020-09-19 10:52:36 --> Severity: Notice --> Undefined property: stdClass::$total_amount C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 135
ERROR - 2020-09-19 10:52:36 --> Severity: Notice --> Undefined property: stdClass::$total_amount C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 135
