<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-26 15:00:21 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 326
ERROR - 2020-09-26 15:00:21 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 326
ERROR - 2020-09-26 15:00:30 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 326
ERROR - 2020-09-26 15:00:30 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 326
ERROR - 2020-09-26 15:01:05 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 326
ERROR - 2020-09-26 15:01:05 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 326
ERROR - 2020-09-26 15:01:45 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 326
ERROR - 2020-09-26 15:01:45 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 326
ERROR - 2020-09-26 15:02:16 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 326
ERROR - 2020-09-26 15:02:16 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 326
ERROR - 2020-09-26 15:02:31 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 326
ERROR - 2020-09-26 15:02:31 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 326
ERROR - 2020-09-26 15:02:36 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 326
ERROR - 2020-09-26 15:02:36 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 326
ERROR - 2020-09-26 15:02:47 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 326
ERROR - 2020-09-26 15:02:47 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 326
ERROR - 2020-09-26 15:05:02 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 326
ERROR - 2020-09-26 15:05:02 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 326
ERROR - 2020-09-26 15:05:11 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 326
ERROR - 2020-09-26 15:05:11 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 326
ERROR - 2020-09-26 15:05:44 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 326
ERROR - 2020-09-26 15:05:44 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 326
ERROR - 2020-09-26 15:16:29 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 384
ERROR - 2020-09-26 15:16:29 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 384
ERROR - 2020-09-26 15:16:29 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 385
ERROR - 2020-09-26 15:16:29 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Activity.php 385
ERROR - 2020-09-26 15:49:43 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 326
ERROR - 2020-09-26 15:49:43 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 326
ERROR - 2020-09-26 17:48:51 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 326
ERROR - 2020-09-26 17:48:52 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 326
ERROR - 2020-09-26 19:36:26 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Apartment.php 298
ERROR - 2020-09-26 19:36:26 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Apartment.php 299
ERROR - 2020-09-26 19:40:33 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Apartment.php 298
ERROR - 2020-09-26 19:40:33 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Apartment.php 299
ERROR - 2020-09-26 19:40:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Apartment.php 298
ERROR - 2020-09-26 19:40:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Apartment.php 299
ERROR - 2020-09-26 19:43:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Apartment.php 298
ERROR - 2020-09-26 19:43:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Apartment.php 299
ERROR - 2020-09-26 19:47:24 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Apartment.php 298
ERROR - 2020-09-26 19:47:24 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Apartment.php 299
ERROR - 2020-09-26 19:47:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Apartment.php 298
ERROR - 2020-09-26 19:47:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Apartment.php 299
ERROR - 2020-09-26 19:47:49 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Apartment.php 298
ERROR - 2020-09-26 19:47:49 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Apartment.php 299
ERROR - 2020-09-26 19:48:02 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Apartment.php 298
ERROR - 2020-09-26 19:48:02 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\personal-work\application\controllers\Apartment.php 299
