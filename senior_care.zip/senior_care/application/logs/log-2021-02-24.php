<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-24 09:46:09 --> 404 Page Not Found: Users/Home
ERROR - 2021-02-24 09:46:13 --> 404 Page Not Found: Users/Home
ERROR - 2021-02-24 09:47:02 --> 404 Page Not Found: Users/Home
ERROR - 2021-02-24 09:48:30 --> 404 Page Not Found: Users/Home
ERROR - 2021-02-24 09:50:37 --> 404 Page Not Found: Users/Home
ERROR - 2021-02-24 10:03:54 --> 404 Page Not Found: Users/Home
ERROR - 2021-02-24 11:01:34 --> 404 Page Not Found: Users/Home
ERROR - 2021-02-24 11:20:23 --> Severity: error --> Exception: C:\xampp\htdocs\senior_care\application\models/PatientDb.php exists, but doesn't declare class PatientDb C:\xampp\htdocs\senior_care\system\core\Loader.php 340
ERROR - 2021-02-24 11:22:15 --> Severity: error --> Exception: C:\xampp\htdocs\senior_care\application\models/PatientDb.php exists, but doesn't declare class PatientDb C:\xampp\htdocs\senior_care\system\core\Loader.php 340
ERROR - 2021-02-24 12:54:17 --> 404 Page Not Found: Userguide/index
