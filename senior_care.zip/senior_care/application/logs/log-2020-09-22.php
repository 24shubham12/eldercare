<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-22 06:48:26 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 279
ERROR - 2020-09-22 06:48:26 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 279
ERROR - 2020-09-22 06:48:26 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 279
ERROR - 2020-09-22 06:48:26 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 279
ERROR - 2020-09-22 06:48:29 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 279
ERROR - 2020-09-22 06:48:29 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 279
ERROR - 2020-09-22 06:48:29 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 279
ERROR - 2020-09-22 06:48:29 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 279
ERROR - 2020-09-22 06:48:32 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 279
ERROR - 2020-09-22 06:48:32 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 279
ERROR - 2020-09-22 06:48:32 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 279
ERROR - 2020-09-22 06:48:32 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 279
ERROR - 2020-09-22 06:48:40 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 279
ERROR - 2020-09-22 06:48:40 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 279
ERROR - 2020-09-22 06:48:40 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 279
ERROR - 2020-09-22 06:48:40 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 279
ERROR - 2020-09-22 06:48:43 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 279
ERROR - 2020-09-22 06:48:43 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 279
ERROR - 2020-09-22 06:48:43 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 279
ERROR - 2020-09-22 06:48:43 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 279
ERROR - 2020-09-22 06:48:47 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 279
ERROR - 2020-09-22 06:48:47 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 279
ERROR - 2020-09-22 06:48:47 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 279
ERROR - 2020-09-22 06:48:47 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 279
ERROR - 2020-09-22 06:48:49 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 279
ERROR - 2020-09-22 06:48:49 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 279
ERROR - 2020-09-22 06:48:49 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 279
ERROR - 2020-09-22 06:48:49 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 279
ERROR - 2020-09-22 06:48:52 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 279
ERROR - 2020-09-22 06:48:52 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 279
ERROR - 2020-09-22 06:48:52 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 279
ERROR - 2020-09-22 06:48:52 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 279
ERROR - 2020-09-22 06:49:10 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 279
ERROR - 2020-09-22 06:49:10 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 279
ERROR - 2020-09-22 06:49:10 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 279
ERROR - 2020-09-22 06:49:10 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 279
ERROR - 2020-09-22 06:49:13 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 279
ERROR - 2020-09-22 06:49:13 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 279
ERROR - 2020-09-22 06:49:13 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 279
ERROR - 2020-09-22 06:49:13 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 279
ERROR - 2020-09-22 06:49:20 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 279
ERROR - 2020-09-22 06:49:20 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 279
ERROR - 2020-09-22 06:49:20 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 279
ERROR - 2020-09-22 06:49:20 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 279
ERROR - 2020-09-22 06:49:22 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 279
ERROR - 2020-09-22 06:49:22 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 279
ERROR - 2020-09-22 06:49:22 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 279
ERROR - 2020-09-22 06:49:22 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 279
ERROR - 2020-09-22 06:50:31 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 279
ERROR - 2020-09-22 06:50:31 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 279
ERROR - 2020-09-22 06:50:31 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 279
ERROR - 2020-09-22 06:50:31 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 279
ERROR - 2020-09-22 06:50:47 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 279
ERROR - 2020-09-22 06:50:47 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 279
ERROR - 2020-09-22 06:50:47 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 279
ERROR - 2020-09-22 06:50:47 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 279
ERROR - 2020-09-22 06:50:51 --> Severity: Notice --> Undefined variable: act_row C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 52
ERROR - 2020-09-22 06:50:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 52
ERROR - 2020-09-22 06:50:51 --> Severity: Notice --> Undefined property: stdClass::$payment_status C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 226
ERROR - 2020-09-22 06:50:51 --> Severity: Notice --> Undefined property: stdClass::$payment_status C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 226
ERROR - 2020-09-22 06:52:54 --> Severity: Notice --> Undefined variable: act_row C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 52
ERROR - 2020-09-22 06:52:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 52
ERROR - 2020-09-22 06:52:54 --> Severity: Notice --> Undefined property: stdClass::$payment_status C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 226
ERROR - 2020-09-22 06:52:54 --> Severity: Notice --> Undefined property: stdClass::$payment_status C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 226
ERROR - 2020-09-22 06:53:18 --> Severity: Notice --> Undefined property: stdClass::$payment_status C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 226
ERROR - 2020-09-22 06:53:18 --> Severity: Notice --> Undefined property: stdClass::$payment_status C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 226
ERROR - 2020-09-22 06:54:49 --> Severity: Notice --> Undefined property: stdClass::$payment_status C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 228
ERROR - 2020-09-22 06:54:49 --> Severity: Notice --> Undefined property: stdClass::$payment_status C:\xampp\htdocs\personal-work\application\views\admin\activity\manage_activity.php 228
ERROR - 2020-09-22 07:11:59 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 279
ERROR - 2020-09-22 07:11:59 --> Severity: Notice --> Trying to get property 'actvity_fees_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 279
ERROR - 2020-09-22 07:11:59 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 279
ERROR - 2020-09-22 07:11:59 --> Severity: Notice --> Trying to get property 'act_id' of non-object C:\xampp\htdocs\personal-work\application\views\admin\activity\add_fees.php 279
